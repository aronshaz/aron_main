import pandas as pd

df = pd.read_json (r'/home/pi/RSL/funda/funda/funda_sold_1000.json')
export_csv = df.to_csv (r'/home/pi/RSL/funda/funda/funda_sold_1000.csv', index = None, header=True)