import scrapy

class SpiderMan(scrapy.Spider):

    # Defining Spider name, page_number to be used for page iteration later on, and the starting url
    name = 'trustpilot_makelaars'
    page_number = 2
    start_urls = ['https://nl.trustpilot.com/categories/real_estate_agents',
    'https://nl.trustpilot.com/categories/real_estate_agents?page=2/']

    # Creating function to define the links to be followed
    def parse(self, response):
        urls =  response.css('div.businessUnitCardsContainer___Qhix1 > a::attr(href)').extract()
        for url in urls:
            url = "https://nl.trustpilot.com" + str(url)
            yield scrapy.Request(url=url, callback=self.parse_details)

    # Defining the url to follow
        #next_page = "https://nl.trustpilot.com/categories/real_estate_agents?page="+ str(SpiderMan.page_number) + "/"
        #if SpiderMan.page_number <=3:
            #SpiderMan.page_number = SpiderMan.page_number + 1
            #next_page = response.urljoin(next_page)
            #yield scrapy.Request(next_page, callback=self.parse)

    # Defining the objects of the pages to be scraped
    def parse_details(self, response):
        agent_url = response.url       
        #if response.css('span.multi-size-header__big::text'):
        #    agent_name = (response.css('span.multi-size-header__big::span').get()).strip()
        #else : 
        #    agent_name = "N/A"
        
        if response.css('div.star-rating.star-rating--medium > img::attr(alt)'):
            review_score = response.css('div.star-rating.star-rating--medium > img::attr(alt)').get()
        else : 
            review_score = "N/A"

        if response.css('p.review-content__text::text'): 
            review_text_1 = (response.css('p.review-content__text::text').get()).strip()
        else : 
            review_text_1 = "N/A"
        
        if response.css('p.review-content__text::text'): 
            review_text_2 = (response.css('p.review-content__text::text')[1].get()).strip()
        else : 
            review_text_2 = "N/A"
        
        if response.css('p.review-content__text::text'): 
            review_text_3 = (response.css('p.review-content__text::text')[2].get()).strip()
        else : 
            review_text_3 = "N/A"

        if response.css('span.headline__review-count::text'):
            reviews_count = (response.css('span.headline__review-count::text').get()).strip()
        else :
            reviews_count = "N/A"
        

    # Export the  data
        yield{
            
            'agent_url' : agent_url,
            #'agent_name' : agent_name,
            'review_score' : review_score,
            'review_text_1' : review_text_1,
            'review_text_2' : review_text_2,
            'review_text_3' : review_text_3,
            'reviews_count' : reviews_count,

        } 
