import scrapy

class SpiderMan(scrapy.Spider):

    # Defining Spider name, page_number to be used for page iteration later on, and the starting url
    name = 'funda_broker_reviews'
    page_number = 2
    start_urls = ['https://www.funda.nl/koop/heel-nederland/verkocht/sorteer-afmelddatum-af/']

    # Creating function to define the links to be followed in order to iterate between page numbers of sold houses
    def parse(self, response):
        urls =  response.css('div.search-result__header-title-col > a::attr(href)').extract()
        for url in urls:
            url = response.urljoin(url)
            yield scrapy.Request(url=url, callback=self.parse_details)

    # Defining the url to follow
        next_page = "https://www.funda.nl/koop/heel-nederland/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number) + "/"
        if SpiderMan.page_number <=1:
            SpiderMan.page_number = SpiderMan.page_number + 1
            next_page = response.urljoin(next_page)
            yield scrapy.Request(next_page, callback=self.parse)

    def parse_details(self, response):      
    # Creating function to define the links to be followed in order to extract information about the broker
        broker_urls =  response.css('a.object-contact-aanbieder-link::attr(href)').extract()
        for broker_url in broker_urls:
            broker_url = response.urljoin(broker_url)
            yield scrapy.Request(url=broker_url, callback=self.parse_broker)

    # Export the broker data
    def parse_broker(self, response):
        review_urls =  response.css('a.gtm-makelaar-detail-reviews-verkoop::attr(href)').extract()
        for review_url in review_urls:
            review_url = response.urljoin(review_url)
            yield scrapy.Request(url=review_url, callback=self.parse_reviews)
    
    # Defining the variables to be scraped from the broker pages
    def parse_reviews(self, response):

    # Broker name
        if response.css("h1[itemprop='name']::text"):
            broker_name = (response.css("h1[itemprop='name']::text").extract()[0]).strip(),
        else :
            broker_name = "N/A"

    # Review author and text 1
        if response.css("div.user-review-author::text"):
            review_author1 = (response.css("div.user-review-author::text").extract()[0]).strip(),
        else :
            review_author1 = "N/A"
        
        if response.css("div.collapse-text-container::text"):
            review_text1 = (response.css("div.collapse-text-container::text").extract()[0]).strip(),
        else : 
            review_text1 = "N/A"
        
    # Review author and text 2
        if response.css("div.user-review-author::text"):
            review_author2 = (response.css("div.user-review-author::text").extract()[1]).strip(),
        else :
            review_author2 = "N/A"
        
        if response.css("div.collapse-text-container::text"):
            review_text2 = (response.css("div.collapse-text-container::text").extract()[1]).strip(),
        else : 
            review_text2 = "N/A"

    # Review author and text 3
        if response.css("div.user-review-author::text"):
            review_author3 = (response.css("div.user-review-author::text").extract()[1]).strip(),
        else :
            review_author3 = "N/A"
        
        if response.css("div.collapse-text-container::text"):
            review_text3 = (response.css("div.collapse-text-container::text").extract()[1]).strip(),
        else : 
            review_text3 = "N/A"

    # Broker url
        broker_reviews_url = response.url

        yield{
            
            'broker_name' : broker_name,
            'review_author1' : review_author1,
            'review_text1' : review_text1,
            'review_author2' : review_author2,
            'review_text2' : review_text2,
            'review_author3' : review_author3,
            'review_text3' : review_text3,
            'broker_reviews_url' : broker_reviews_url

        } 