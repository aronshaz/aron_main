import scrapy
import re


class SpiderMan(scrapy.Spider):
    # Defining Spider name, page_number to be used for page iteration later on, and the starting url
    name = 'funda_images'
    page_number = 2
    start_urls = ['https://www.funda.nl/koop/heel-nederland/verkocht/sorteer-afmelddatum-af/']

    # Creating function to define the links to be followed in order to iterate between page numbers of sold houses
    def parse(self, response):
        urls = response.css('div.search-result__header-title-col > a::attr(href)').extract()
        for url in urls:
            url = response.urljoin(url)
            yield scrapy.Request(url=url, callback=self.parse_details)

        # Defining the url to follow
        next_page = "https://www.funda.nl/koop/heel-nederland/verkocht/sorteer-afmelddatum-af/p" + str(
            SpiderMan.page_number) + "/"
        if SpiderMan.page_number <= 1:
            SpiderMan.page_number = SpiderMan.page_number + 1
            next_page = response.urljoin(next_page)
            yield scrapy.Request(next_page, callback=self.parse)


    # Defining the objects of the house pages to be scraped
    def parse_details(self, response):

        if response.css('span.object-header__title::text'):
            address = (response.css('span.object-header__title::text').get()).strip()
        else:
            address = "N/A"

        if response.css('span.object-header__subtitle::text'):
            zipcode_city = (response.css('span.object-header__subtitle::text').get()).strip()
        else:
            zipcode_city = "N/A"

        raw_image_urls = response.css('div.object-media-foto > a > img::attr(src)').getall()
        print(raw_image_urls)

        url = response.url

        # Export the housing data
        yield {

            'image_urls': raw_image_urls,
            'address': address,
            'zipcode_city': zipcode_city,
            'url': url,
        }
