import scrapy

class SpiderMan(scrapy.Spider):

    # Defining Spider name, page_number to be used for page iteration later on, and the starting url
    name = 'funda_broker'
    page_number = 2
    start_urls = ['https://www.funda.nl/koop/heel-nederland/verkocht/sorteer-afmelddatum-af/']

    # Creating function to define the links to be followed in order to iterate between page numbers of sold houses
    def parse(self, response):
        urls =  response.css('div.search-result__header-title-col > a::attr(href)').extract()
        for url in urls:
            url = response.urljoin(url)
            yield scrapy.Request(url=url, callback=self.parse_details)

    # Defining the url to follow
        next_page = "https://www.funda.nl/koop/heel-nederland/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number) + "/"
        if SpiderMan.page_number <=67:
            SpiderMan.page_number = SpiderMan.page_number + 1
            next_page = response.urljoin(next_page)
            yield scrapy.Request(next_page, callback=self.parse)

    def parse_details(self, response):      
    # Creating function to define the links to be followed in order to extract information about the broker
        broker_urls =  response.css('a.object-contact-aanbieder-link::attr(href)').extract()
        for broker_url in broker_urls:
            broker_url = response.urljoin(broker_url)
            yield scrapy.Request(url=broker_url, callback=self.parse_broker)

    # Export the broker data
    def parse_broker(self, response):

        if response.css("h1[itemprop='name']::text"):
            broker_name = (response.css("h1[itemprop='name']::text").extract_first()).strip(),
        else : 
            broker_name = "N/A"

        if response.css('div.object-description-body'):
            broker_about = (response.css('div.object-description-body').get()).strip(),
        else : 
            broker_about = "N/A"    

        if response.css("span[itemprop='reviewCount']::text"):
            reviews = (response.css("span[itemprop='reviewCount']::text").extract_first()).strip(),
        else : 
            reviews = "N/A"
        
        if response.xpath("//dt[contains(.,'Dienstverlening')]/following-sibling::dd[1]/text()"):
            services = (response.xpath("//dt[contains(.,'Dienstverlening')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        else : 
            services = "N/A"

        if response.xpath("//dt[contains(.,'Specialisme')]/following-sibling::dd[1]/text()"):
            specialty = (response.xpath("//dt[contains(.,'Specialisme')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        else : 
            specialty = "N/A"

        if response.xpath("//dt[contains(.,'Certificering')]/following-sibling::dd[1]/text()"):
            certification = (response.xpath("//dt[contains(.,'Certificering')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        else : 
            certification = "N/A"   

        if response.xpath("//dt[contains(.,'Gecertificeerd')]/following-sibling::dd[1]/text()"):
            certification2 = (response.xpath("//dt[contains(.,'Gecertificeerd')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        else : 
            certification2 = "N/A"   

        if response.xpath("//dt[contains(.,'Aanbod')]/following-sibling::dd[1]/text()"):
            offer = (response.xpath("//dt[contains(.,'Aanbod')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        else : 
            offer = "N/A"

        if response.css("p[itemprop='reviewBody']::text"):
            quote = (response.css("p[itemprop='reviewBody']::text").extract_first()).strip(),
        else : 
            quote = "N/A"
        
        if response.css('div.makelaars-review-item-average::text'):
            knowledge = response.css('div.makelaars-review-item-average::text')[0].get(),
        else : 
            knowledge = "N/A"

        if response.css('div.makelaars-review-item-average::text'):
            expertise = response.css('div.makelaars-review-item-average::text')[1].get(),
        else : 
            expertise = "N/A"

        if response.css('div.makelaars-review-item-average::text'):
            service_support = response.css('div.makelaars-review-item-average::text')[2].get(),
        else : 
            service_support = "N/A"   

        if response.css('div.makelaars-review-item-average::text'):
            price_quality = response.css('div.makelaars-review-item-average::text')[3].get(),
        else : 
            price_quality = "N/A"

        if response.css('div.makelaars-stats-number::text'):
            sold_properties = response.css('div.makelaars-stats-number::text').get(),
        else : 
            sold_properties = "N/A"   

        if response.css("span[itemprop='postalCode']::text"):
            broker_postcode = (response.css("span[itemprop='postalCode']::text").extract_first()).strip(),
        else : 
            broker_postcode = "N/A"   
        
        if response.css("span[itemprop='streetAddress']::text"):
            broker_address = (response.css("span[itemprop='streetAddress']::text").extract_first()).strip(),
        else : 
            broker_address = "N/A"   

        if response.css("span[itemprop='addressLocality']::text"):
            broker_city = (response.css("span[itemprop='addressLocality']::text").extract_first()).strip(),
        else : 
            broker_city = "N/A"   
        
        url = response.url

        yield{
            
            'broker_name' : broker_name,
            'broker_about' : broker_about,
            'reviews' : reviews,
            'services' : services,
            'speciality' : specialty,
            'certification' : certification,
            'certification2' : certification2, 
            'offer' : offer,
            'quote' : quote, 
            'knowledge' : knowledge,
            'expertise' : expertise,
            'service_support' : service_support,
            'price_quality' : price_quality,
            'sold_properties' : sold_properties,
            'broker_address' : broker_address,
            'broker_postcode' : broker_postcode,
            'broker_city' : broker_city,
            'url' : url,
        } 
