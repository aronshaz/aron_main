import scrapy

class SpiderMan(scrapy.Spider):

    # Defining Spider name, page_number to be used for page iteration later on, and the starting url
    name = 'funda_province'
    start_urls = ['https://www.funda.nl/koop/provincie-groningen/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-friesland/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-drenthe/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-overijssel/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-flevoland/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-gelderland/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-utrecht/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-noord-holland/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-zuid-holland/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-zeeland/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-noord-brabant/verkocht/sorteer-afmelddatum-af/',
    'https://www.funda.nl/koop/provincie-limburg/verkocht/sorteer-afmelddatum-af/',]

    # Defining the variables which allow for mulitple page scraping for every province
    page_number_groningen = 2
    page_number_friesland = 2
    page_number_drenthe = 2
    page_number_overijssel = 2
    page_number_flevoland = 2
    page_number_gelderland = 2
    page_number_utrecht = 2
    page_number_noord_holland = 2
    page_number_zuid_holland = 2
    page_number_zeeland = 2
    page_number_noord_brabant = 2
    page_number_limburg = 2

    # Creating function to define the links to be followed in order to iterate between page numbers of sold houses
    def parse(self, response):
        urls =  response.css('div.search-result__header-title-col > a::attr(href)').extract()
        for url in urls:
            url = response.urljoin(url)
            yield scrapy.Request(url=url, callback=self.parse_details)

    # Defining the url to follow for each province. Number of scraped pages is according to the number of inhabitants living there
        if "groningen" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-groningen/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_groningen) + "/"
            if SpiderMan.page_number_groningen <= 2:
                SpiderMan.page_number_groningen = SpiderMan.page_number_groningen + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)

        if "friesland" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-friesland/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_friesland) + "/"
            if SpiderMan.page_number_friesland <= 3:
                SpiderMan.page_number_friesland = SpiderMan.page_number_friesland + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)
        
        if "drenthe" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-drenthe/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_drenthe) + "/"
            if SpiderMan.page_number_drenthe <= 2:
                SpiderMan.page_number_drenthe = SpiderMan.page_number_drenthe + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)
        
        if "overijssel" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-overijssel/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_overijssel) + "/"
            if SpiderMan.page_number_overijssel <= 5:
                SpiderMan.page_number_overijssel = SpiderMan.page_number_overijssel + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)
        
        if "flevoland" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-flevoland/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_flevoland) + "/"
            if SpiderMan.page_number_flevoland <= 2:
                SpiderMan.page_number_flevoland = SpiderMan.page_number_flevoland + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)
        
        if "gelderland" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-gelderland/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_gelderland) + "/"
            if SpiderMan.page_number_gelderland <= 8:
                SpiderMan.page_number_gelderland = SpiderMan.page_number_gelderland + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)
        
        if "utrecht" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-utrecht/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_utrecht) + "/"
            if SpiderMan.page_number_utrecht <= 6:
                SpiderMan.page_number_utrecht = SpiderMan.page_number_utrecht + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)
        
        if "noord-holland" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-noord-holland/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_noord_holland) + "/"
            if SpiderMan.page_number_noord_holland <= 12:
                SpiderMan.page_number_noord_holland = SpiderMan.page_number_noord_holland + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)
        
        if "zuid-holland" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-zuid-holland/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_zuid_holland) + "/"
            if SpiderMan.page_number_zuid_holland <= 14:
                SpiderMan.page_number_zuid_holland = SpiderMan.page_number_zuid_holland + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)
        
        if "zeeland" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-zeeland/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_zeeland) + "/"
            if SpiderMan.page_number_zeeland <= 2:
                SpiderMan.page_number_zeeland = SpiderMan.page_number_zeeland + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)
        
        if "noord-brabant" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-noord-brabant/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_noord_brabant) + "/"
            if SpiderMan.page_number_noord_brabant <= 10:
                SpiderMan.page_number_noord_brabant = SpiderMan.page_number_noord_brabant + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)
        
        if "limburg" in response.url:
            next_page = "https://www.funda.nl/koop/provincie-limburg/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number_limburg) + "/"
            if SpiderMan.page_number_limburg <= 4:
                SpiderMan.page_number_limburg = SpiderMan.page_number_limburg + 1
                next_page = response.urljoin(next_page)
                yield scrapy.Request(next_page, callback=self.parse)

    # Defining the objects of the house pages to be scraped
    def parse_details(self, response):

        if response.css('span.object-header__title::text'):
            address = (response.css('span.object-header__title::text').get()).strip()
        else : 
            address = "N/A"
        
        if response.css('span.object-header__subtitle::text'): 
            zipcode_city = (response.css('span.object-header__subtitle::text').get()).strip()
        else : 
            zipcode_city = "N/A"
        
        if response.css('strong.object-header__price--historic::text'):
            asking_price = (response.css('strong.object-header__price--historic::text').get()).strip()
        else :
            asking_price = "N/A"

        if response.xpath("//dt[contains(.,'Vraagprijs per m²')]/following-sibling::dd[1]/text()"):
            asking_price_per_m2 = (response.xpath("//dt[contains(.,'Vraagprijs per m²')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else : 
            asking_price_per_m2 = "N/A"
        
        if response.xpath("//dt[contains(.,'Wonen')]/following-sibling::dd[1]/text()"):
            living_area = (response.xpath("//dt[contains(.,'Wonen')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            living_area = "N/A"
        
        if response.xpath("//dt[contains(.,'Perceel')]/following-sibling::dd[1]/text()"):
            property_area = (response.xpath("//dt[contains(.,'Perceel')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            property_area = "N/A"
        
        if response.xpath("//dt[contains(.,'Bouwjaar')]/following-sibling::dd[1]/text()"):
            build_year = (response.xpath("//dt[contains(.,'Bouwjaar')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            build_year = "N/A"

        if response.xpath("//dt[contains(.,'Soort woonhuis')]/following-sibling::dd[1]/text()"):
            house_type = (response.xpath("//dt[contains(.,'Soort woonhuis')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else : 
            house_type = "N/A"
        
        if response.css('div.object-description-body::text'):
            description = (response.css('div.object-description-body::text').get()).strip()
        else :
            description = "N/A"
        
        if response.xpath("//dt[contains(.,'Aantal kamers')]/following-sibling::dd[1]/text()"):
            rooms = (response.xpath("//dt[contains(.,'Aantal kamers')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            rooms = "N/A"
        
        if response.xpath("//dt[contains(.,'Aantal badkamers')]/following-sibling::dd[1]/text()"):
            bathrooms = (response.xpath("//dt[contains(.,'Aantal badkamers')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else : 
            bathrooms = "N/A"

        if response.xpath("//dt[contains(.,'Badkamervoorzieningen')]/following-sibling::dd[1]/text()"):
            bathroom_facilities = (response.xpath("//dt[contains(.,'Badkamervoorzieningen')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else : 
            bathroom_facilities = "N/A"
        
        if response.xpath("//dt[contains(.,'Aantal woonlagen')]/following-sibling::dd[1]/text()"):
            number_of_stories = (response.xpath("//dt[contains(.,'Aantal woonlagen')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            number_of_stories = "N/A"
        
        if response.css('span.energielabel::text'):
            energy_label = (response.css('span.energielabel::text').get()).strip()
        else :
            energy_label = "N/A"
        
        if response.xpath("//dt[contains(.,'Isolatie')]/following-sibling::dd[1]/text()"):
            insulation = (response.xpath("//dt[contains(.,'Isolatie')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            insulation = "N/A"

        if response.xpath("//dt[contains(.,'Verwarming')]/following-sibling::dd[1]/text()"):
            heating = (response.xpath("//dt[contains(.,'Verwarming')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            heating = "N/A"
        
        if response.xpath("//dt[contains(.,'Warm water')]/following-sibling::dd[1]/text()"):
            hot_water = (response.xpath("//dt[contains(.,'Warm water')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            hot_water = "N/A"

        if response.xpath("//dt[contains(.,'Eigendomssituatie')]/following-sibling::dd[1]/text()"):
            ownership = (response.xpath("//dt[contains(.,'Eigendomssituatie')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else : 
            ownership = "N/A"
        
        if response.xpath("//dt[contains(.,'Ligging')]/following-sibling::dd[1]/text()"):
            location = (response.xpath("//dt[contains(.,'Ligging')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else:
            location = "N/A"

        if response.xpath("//dt[contains(.,'Tuin')]/following-sibling::dd[1]/text()"):
            garden = (response.xpath("//dt[contains(.,'Tuin')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            garden = "N/A"
        
        if response.xpath("//dt[contains(.,'Achtertuin')]/following-sibling::dd[1]/text()"):
            back_garden = (response.xpath("//dt[contains(.,'Achtertuin')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            back_garden = "N/A"

        if response.xpath("//dt[contains(.,'Ligging tuin')]/following-sibling::dd[1]/text()"):
            garden_location = (response.xpath("//dt[contains(.,'Ligging tuin')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            garden_location = "N/A"

        if response.xpath("//dt[contains(.,'Soort parkeergelegenheid')]/following-sibling::dd[1]/text()"):
            parking = (response.xpath("//dt[contains(.,'Soort parkeergelegenheid')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            parking = "N/A"

        if response.css('span.object-header__subtitle::text'):
            agent = (response.css('span.object-header__subtitle::text').get()).strip()
        else :
            agent = "N/A"
        
        if response.xpath("//dt[contains(.,'Aangeboden sinds')]/following-sibling::dd[1]/text()"):
            listed_since = (response.xpath("//dt[contains(.,'Aangeboden sinds')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else : 
            listed_since = "N/A"
        
        if response.xpath("//dt[contains(.,'Verkoopdatum')]/following-sibling::dd[1]/text()"):
            selling_date = (response.xpath("//dt[contains(.,'Verkoopdatum')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            selling_date = "N/A"

        if response.xpath("//dt[contains(.,'Looptijd')]/following-sibling::dd[1]/text()"):
            term = (response.xpath("//dt[contains(.,'Looptijd')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        else :
            term = "N/A"

        if response.css('h2.object-contact-header-title::text'):
            pictures = (response.css('h2.object-contact-header-title::text').get()).strip()
        else :
            pictures = "N/A"
        
        url = response.url

    # Export the housing data
        yield{
            
            'address' : address,
            'zipcode_city' : zipcode_city,
            'asking_price' : asking_price,
            'asking_price_per_m2' : asking_price_per_m2,
            'living_area' : living_area,
            'property_area' : property_area,
            'build_year' : build_year,
            'garden' : garden,
            'house_type' : house_type,
            'description' : description,
            'rooms' : rooms,
            'bathrooms' : bathrooms,
            'batchroom_facilities' : bathroom_facilities,
            'number_of_stories' : number_of_stories,
            'energy_label' : energy_label,
            'insulation' : insulation,
            'heating' : heating,
            'hot_water' : hot_water,
            'ownership' : ownership,
            'location' : location,
            'garden' : garden,
            'back_garden' : back_garden,
            'garden_location' : garden_location,
            'parking' : parking,
            'agent' : agent,
            'listed_since' : listed_since,
            'selling_date' : selling_date,
            'term' : term,
            'pictures' : pictures,
            'url' : url,

        }
