import scrapy
import re

class SpiderMan(scrapy.Spider):

    # Defining Spider name, page_number to be used for page iteration later on, and the starting url
    name = 'funda_test'
    page_number = 2
    start_urls = ['https://www.funda.nl/koop/heel-nederland/verkocht/sorteer-afmelddatum-af/']

    # Creating function to define the links to be followed in order to iterate between page numbers of sold houses
    def parse(self, response):
        urls =  response.css('div.search-result__header-title-col > a::attr(href)').extract()
        for url in urls:
            url = response.urljoin(url)
            yield scrapy.Request(url=url, callback=self.parse_details)

    # Defining the url to follow
        next_page = "https://www.funda.nl/koop/heel-nederland/verkocht/sorteer-afmelddatum-af/p"+ str(SpiderMan.page_number) + "/"
        if SpiderMan.page_number <=1:
            SpiderMan.page_number = SpiderMan.page_number + 1
            next_page = response.urljoin(next_page)
            yield scrapy.Request(next_page, callback=self.parse)

    # Defining the objects of the house pages to be scraped
    def parse_details(self, response):

        address = (response.css('span.object-header__title::text').get()).strip(), 
        zipcode_city = (response.css('span.object-header__subtitle::text').get()).strip(),
        asking_price = (response.css('strong.object-header__price--historic::text').get()).strip(),
        #asking_price_per_m2 = (response.xpath("//dt[contains(.,'Vraagprijs per m²')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        living_area = (response.css('span.kenmerken-highlighted__value::text').get()).strip(),
        property_area = (response.css('span.kenmerken-highlighted__value::text')[1].get()).strip(),
        build_year = (response.css('dl.object-kenmerken-list > dd.fd-flex--bp-m::text')[5].get()).strip(),
        house_type = (response.xpath("//dt[contains(.,'Soort woonhuis')]/following-sibling::dd[1]/text()").extract()[0]).strip()
        description = (response.css('div.object-description-body::text').get()).strip(),
        rooms = (response.xpath("//dt[contains(.,'Aantal kamers')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        bathrooms = (response.xpath("//dt[contains(.,'Aantal badkamers')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        bathroom_facilities = (response.xpath("//dt[contains(.,'Badkamervoorzieningen')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        number_of_stories = (response.xpath("//dt[contains(.,'Aantal woonlagen')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        energy_label = (response.css('span.energielabel::text').get()).strip(),
        insulation = (response.xpath("//dt[contains(.,'Isolatie')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        heating = (response.xpath("//dt[contains(.,'Verwarming')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        hot_water = (response.xpath("//dt[contains(.,'Warm water')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        ownership = (response.xpath("//dt[contains(.,'Eigendomssituatie')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        location = (response.xpath("//dt[contains(.,'Ligging')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        garden = (response.xpath("//dt[contains(.,'Tuin')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        back_garden = (response.xpath("//dt[contains(.,'Achtertuin')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        garden_location = (response.xpath("//dt[contains(.,'Ligging tuin')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        parking = (response.xpath("//dt[contains(.,'Soort parkeergelegenheid')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        agent = (response.css('span.object-header__subtitle::text').get()).strip(),
        listed_since = (response.xpath("//dt[contains(.,'Aangeboden sinds')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        selling_date = (response.xpath("//dt[contains(.,'Verkoopdatum')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        term = (response.xpath("//dt[contains(.,'Looptijd')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        pictures = (response.css('h2.object-contact-header-title::text').get()).strip(),
        url = response.url,

    # Export the housing data
        yield{
            
            'address' : address,
            'zipcode_city' : zipcode_city,
            'asking_price' : asking_price,
            #'asking_price_per_m2' : asking_price_per_m2,
            'living_area' : living_area,
            'property_area' : property_area,
            'build_year' : build_year,
            'garden' : garden,
            'house_type' : house_type,
            'description' : description,
            'rooms' : rooms,
            'bathrooms' : bathrooms,
            'batchroom_facilities' : bathroom_facilities,
            'number_of_stories' : number_of_stories,
            'energy_label' : energy_label,
            'insulation' : insulation,
            'heating' : heating,
            'ownership' : ownership,
            'location' : location,
            'garden' : garden,
            'garden_location' : garden_location,
            'parking' : parking,
            'agent' : agent,
            'listed_since' : listed_since,
            'selling_date' : selling_date,
            'term' : term,
            'pictures' : pictures,
            'url' : url,

        } 

    # Creating function to define the links to be followed in order to extract information about the broker
        broker_urls =  response.css('a.object-contact-aanbieder-link::attr(href)').extract()
        for broker_url in broker_urls:
            broker_url = response.urljoin(broker_url)
            yield scrapy.Request(url=broker_url, callback=self.parse_broker)

    # Export the broker data
    def parse_broker(self, response):

        #about_us_broker = (response.css('p::text').get()).strip(),
        reviews = (response.css("span[itemprop='reviewCount']::text").extract_first()).strip(),
        #specialty = (response.xpath("//dt[contains(.,'Specialisme')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        #certification = (response.xpath("//dt[contains(.,'Certificering')]/following-sibling::dd[1]/text()").extract()[0]).strip(),
        quote = (response.css("p[itemprop='reviewBody']::text").extract_first()).strip(),
        #total_rating = response.css("span[itemprop='ratingValue']::text").getall(),
        knowledge = response.css('div.makelaars-review-item-average::text')[0].get(),
        expertise = response.css('div.makelaars-review-item-average::text')[1].get(),
        service_support = response.css('div.makelaars-review-item-average::text')[2].get(),
        price_quality = response.css('div.makelaars-review-item-average::text')[3].get(),
        sold_properties = response.css('div.makelaars-stats-number::text').get(),

        yield{
            
            #'about_us_broker' : ...
            'reviews' : reviews,
            #'speciality' : specialty,
            #'certification' : certification, 
            'quote' : quote, 
            #'total_rating' : ...
            'knowledge' : knowledge,
            'expertise' : expertise,
            'service_support' : service_support,
            'price_quality' : price_quality,
            'sold_properties' : sold_properties,
        } 
