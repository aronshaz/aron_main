import scrapy

#selectors are working but no time left to make the whole spider working


class MuseumSpider(scrapy.Spider):

    name = 'museum'
    page_number = 2
    start_urls = ['https://whichmuseum.com/the-netherlands/cities']

  
   # Creating function to define the links to be followed in order to iterate between page numbers of sold houses
    def parse(self, response):
        urls =  response.xpath('//div/a/@href').extract()[0]
        for url in urls:
            url = response.urljoin(url)
            yield scrapy.Request(url=url, callback=self.parse_details)

   # Defining the url to follow
        next_page = "https://whichmuseum.com/the-netherlands/cities/p"+ str(MuseumSpider.page_number) + "/"
        if MuseumSpider.page_number <=1:
            MuseumSpider.page_number = MuseumSpider.page_number + 1
            next_page = response.urljoin(next_page)
            yield scrapy.Request(next_page, callback=self.parse)


    def parse_details(self, response):      
    # Creating function to define the links to be followed in order to extract information about the museum
        museum_urls =  response.xpath('//td/a/@href').extract()[0]
        for museum_url in museum_urls:
            museum_url = response.urljoin(museum_url)
            yield scrapy.Request(url=museum_url, callback=self.parse_museum)


    # Export the museum data
    def parse_museum(self, response):
        review_urls =  response.css('ul.button-group stack-for-small no-border-bottom > a::attr(href)').extract()
        for review_url in review_urls:
            review_url = response.urljoin(review_url)
            yield scrapy.Request(url=review_url, callback=self.parse_reviews)
    
    # Defining the variables to be scraped from the museum pages
    
    def parse_reviews(self, response):

    # museum name

        if response.xpath('//td/a/text()').extract()[0]:
            museum_name = (response.xpath('//td/a/text()').extract()[0]).strip(),
        else :
            museum_name = "N/A"  


        if response.xpath('//td[@class="show-for-medium-up"]/text()').extract():
            museum_address = (response.xpath('//td[@class="show-for-medium-up"]/text()').extract()).strip(),
        else :
            museum_address = "N/A"


        if response.xpath('//td/a/text()').extract()[1]:
            museum_city = (response.xpath('//td/a/text()').extract()[1]).strip(),
        else :
            museum_city = "N/A" 


        if response.xpath('//div/p[@class="description"]/text()').extract():
            museum_description = (response.xpath('//div/p[@class="description"]/text()').extract()).strip(),
        else :
            museum_description = "N/A" 


        if response.xpath('//div/a[@class="underline"]/text()').extract()[0]:
            phonenumber = (response.xpath('//div/a[@class="underline"]/text()').extract()[0]).strip(),
        else :
            phonenumber = "N/A" 


        if response.xpath('//div/span/text()').extract()[10]:
            museumtype = (response.xpath('//div/span/text()').extract()[10]).strip(),
        else :
            museumtype = "N/A" 


        if response.xpath('//div/span[@class="topic"]/text()').extract():
            topics = (response.xpath('//div/span[@class="topic"]/text()').extract()).strip(),
        else :
            topics = "N/A" 


        if response.xpath('//div[@class="wm-section hours"]').extract():
            opening_hours = (response.xpath('//div[@class="wm-section hours"]').extract()).strip(),
        else :
            opening_hours = "N/A" 


        if response.xpath('//div/p[@class="review no-margin-bottom"]/text()').extract():
            reviews = (response.xpath('//div/p[@class="review no-margin-bottom"]/text()').extract()).strip(),
        else :
            reviews = "N/A" 

    # museum url
        museum_reviews_url = response.url

        yield{
            
            'museum_name' : museum_name,
            'museum_address' : museum_address,
            'museum_city' : museum_city,
            'description' : museum_description,
            'phonenumber' : phonenumber,
            'museumtype' : museumtype,
            'topics' : topics,
            'opening_hours' : opening_hours,
            'reviews' : reviews,

        } 
