import scrapy


class SpiderMan(scrapy.Spider):
    # Defining Spider name, page_number to be used for page iteration later on, and the starting url
    name = 'funda_trustpilot'
    start_urls = ['https://nl.trustpilot.com/review/www.funda.nl']

    # Defining the objects of the review pages to be scraped
    def parse(self, response):
        yield {
            'rating_1': (response.css('div.star-rating.star-rating--medium > img::attr(alt)').get()),
            'review_text_1': (response.css('p.review-content__text::text').get()).strip(),
            'rating_2': (response.css('div.star-rating.star-rating--medium > img::attr(alt)')[1].get()),
            'review_text_2': (response.css('p.review-content__text::text')[1].get()).strip(),
            'rating_3': (response.css('div.star-rating.star-rating--medium > img::attr(alt)')[2].get()),
            'review_text_3': (response.css('p.review-content__text::text')[2].get()).strip(),
            'rating_4': (response.css('div.star-rating.star-rating--medium > img::attr(alt)')[3].get()),
            'review_text_4': (response.css('p.review-content__text::text')[3].get()).strip(),
            'rating_5': (response.css('div.star-rating.star-rating--medium > img::attr(alt)')[4].get()),
            'review_text_5': (response.css('p.review-content__text::text')[4].get()).strip(),
            'all_reviews_text': (response.css('p.review-content__text::text').getall()),
            'rating_avg': (response.css('div.star-rating > img::attr(alt)').get()),
        }
            
