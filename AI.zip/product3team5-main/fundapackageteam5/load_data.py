import pandas as pd
import numpy as np
import os
import datetime

class DataLoader(object):
    
    def __init__ (self, raw_folder, raw_funda_data_name):
        self.raw_folder = raw_folder
        self.raw_funda_data_name = raw_funda_data_name

    def load_data(self):
        funda_data = pd.read_csv(os.path.join(self.raw_folder, self.raw_funda_data_name), engine='python', encoding='utf-8', error_bad_lines=False)
        return funda_data
