import pandas as pd
import numpy as np


class DataPartitioner(object):

    def __init__(self, test_perc = 0.2, crossvalidation_splits = 5, seed = 1235):
        self.test_perc = test_perc
        self.crossvalidation_splits = crossvalidation_splits
        self.seed = seed

    def partition_data(self, funda_data):
        print("Preparing dataset for cross-validation")
        obs = funda_data[['globalId']].copy()
        obs = obs.sort_values(['globalId'])
        obs_test = obs.sample(frac=self.test_perc, random_state=self.seed).copy()
        obs_test = obs_test.assign(test = True).assign(cv_split=np.NaN)
 
        obs_train = (
        obs.merge(obs_test[['globalId']], how= 'left', indicator = True)
        .query("_merge == 'left_only'")
        .drop('_merge', axis = 1)
        .assign(test=False))
        #print(obs_train)
        cv_splits = np.random.randint(1, self.crossvalidation_splits + 1, obs_train.shape[0])
        obs_train= obs_train.assign(cv_split = cv_splits)
        final_obs = pd.concat([obs_test, obs_train]).reset_index(drop=True)
        #print(final_obs)
        return final_obs

#self = DataPartitioner

    

