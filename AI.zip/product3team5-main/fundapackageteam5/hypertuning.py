import pandas as pd
import numpy as np
import itertools
import seaborn as sn
import matplotlib.pyplot as plt
from copy import deepcopy
from sklearn import metrics
from sklearn import preprocessing
from sklearn.metrics import mean_squared_error 
import statistics
import warnings
import tensorflow as tf 
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Flatten
warnings.filterwarnings('ignore')

class Hypertuner:

    def __init__(self, estimator, tuning_params, validation_mapping):
        self.estimator = estimator
        self.tuning_params = tuning_params
        self.validation_mapping = validation_mapping
    
    def tune_model(self, train_set, target, model_type):
        self.target = target
        self.model_type = model_type

        if self.model_type == "rf":
            print("Starting hypertuning for Random Forest model")
            parameter_combos = []
            parameter_combos_dicts = []

            for a in itertools.product(*self.tuning_params.values()): 
                parameter_combos.append(a)

            for i in parameter_combos:
                d = {}
                for j in range(len(i)):
                    d[list(self.tuning_params.keys())[j]] = i[j]
                parameter_combos_dicts.append(d)
            print(f"The parameter combinations which will be used for hypertuning are : {parameter_combos_dicts}")

            validation_mapping_train = self.validation_mapping.query("test == False")  
            train_set = train_set.merge(validation_mapping_train[['globalId', 'cv_split']])
            rmse_list = []
            
            for d in parameter_combos_dicts:
                estimator_cv = deepcopy(self.estimator)
                estimator_cv = estimator_cv.set_params(**d)
                rmse_cv = self.calculate_mean_cv_error(train_set, estimator_cv)
                rmse_list.append(rmse_cv)

            min_rmse = min(rmse_list)
            optimal_rf_param_index = np.argmin(rmse_list)
            optimal_rf_param_combo = parameter_combos_dicts[optimal_rf_param_index]
            
            return optimal_rf_param_combo, min_rmse 
        
        elif self.model_type == "nn":
            print("Starting hypertuning for Neural Network")
            validation_mapping_train = self.validation_mapping.query("test == False")  
            train_set = train_set.merge(validation_mapping_train[['globalId', 'cv_split']])
            cv_errors = []

            estimator_cv = deepcopy(self.estimator)
            rmse_list = self.calculate_mean_cv_error(train_set, estimator_cv)
            min_rmse = min(rmse_list)
            optimal_nn_param_index = np.argmin(rmse_list)
            optimal_nn_param_combo = self.nn_param_combos[optimal_nn_param_index]
            return optimal_nn_param_combo, min_rmse


    def calculate_mean_cv_error(self, train_set, estimator_cv):
        self.train_set = train_set
        self.estimator_cv = estimator_cv

        # Perform cross validation fitting for each split
        splits = train_set['cv_split'].unique().tolist()
        splits.sort()

        rmse_cv = []
        mape_list = []

        #Predict for every cv
        if self.model_type == "rf":
            for i in splits:
                train_split = train_set.query(f"cv_split != {i}") 
                y_train = train_split[self.target]
                X_train = train_split.drop(['globalId', self.target, 'cv_split'],axis=1)
                estimator_cv.fit(X=X_train, y = y_train)
                # evaluate the model on each split
                test_obs = train_set.query(f"cv_split == {i}")
                X_test = test_obs.drop(['globalId', self.target, 'cv_split'],axis=1)
                y_pred = estimator_cv.predict(X_test)

                rmse = mean_squared_error(test_obs[self.target], y_pred, squared=False)
                rmse_cv.append(rmse)

            rmse_cv = statistics.mean(rmse_cv)

        elif self.model_type == "nn":
            self.nn_param_combos = []
            for i in splits:
                train_split = train_set.query(f"cv_split != {i}") 
                y_train = train_split[self.target]
                X_train = train_split.drop(['globalId', self.target, 'cv_split'],axis=1)
                test_obs = train_set.query(f"cv_split == {i}")
                y_test = test_obs[self.target]
                X_test = test_obs.drop(['globalId', self.target, 'cv_split'],axis=1)

                X_train = np.asarray(X_train).astype(np.float32)
                y_train = np.asarray(y_train).astype(np.float32)
                X_test = np.asarray(X_test).astype(np.float32)
                y_test = np.asarray(y_test).astype(np.float32)
        
                estimator_cv.add(Dense(128, input_dim=10, activation='relu'))  
                estimator_cv.add(Dense(256, activation='relu'))
                estimator_cv.add(Dense(256, activation='relu'))
                estimator_cv.add(Dense(1, activation='linear'))
                estimator_cv.compile(loss="mean_squared_error", optimizer="adam", 
                metrics=[tf.keras.metrics.RootMeanSquaredError()])
                
                for batch_size in self.tuning_params['batch_size']:
                    for epoch in self.tuning_params['epochs']:
                        
                        estimator_cv.fit(X_train, y_train, batch_size=batch_size, epochs=epoch, validation_data=(X_test, y_test))
                        y_pred = estimator_cv.predict(X_test)
                        #print(y_pred)
                        # Root Mean Squared Error
                        rmse = mean_squared_error(y_test, y_pred, squared=False)
                        rmse_cv.append(rmse)
                        
            rmse_cv = np.mean(np.array(rmse_cv).reshape(-1, 5), axis=1)
            rmse_cv.tolist()
            for batch_size in self.tuning_params['batch_size']:
                    for epoch in self.tuning_params['epochs']:
                        self.nn_param_combos.append((batch_size, epoch))
                    
        print(rmse_cv)
        #print(mape_list)

        return rmse_cv
