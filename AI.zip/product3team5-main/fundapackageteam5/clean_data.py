import pandas as pd
import numpy as np
#import seaborn as sn
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn import preprocessing

class DataCleaner(object):

    def __init__(self):
        pass

    def clean_data(self, funda_data):
        # Make new clean DataFrame to work with all needed columns
        funda_data = funda_data[['globalId', 'publicatieDatum', 'postcode', 'koopPrijs',
            'volledigeOmschrijving', 'soortWoning', 'categorieObject', 'bouwjaar',
            'indTuin', 'perceelOppervlakte', 'aantalKamers',
            'aantalBadkamers', 'oppervlakte', 
            'datum_ondertekening']].copy()
        #print(funda_data.head())

        # checking for NaN 
        #print(funda_data.isna().sum().sort_values(ascending=False))

        #energielabelKlasse       122755 #too many from energylabel so also drop that column
        #perceelOppervlakte        67241
        #aantalBadkamers           61148
        #koopPrijs                   741
        #all other columns are         0
        #dtype: int64

        # remove all NaN from table 
        funda_data = funda_data.dropna()
        #print(funda_data.head())     

        # We also don't want any attibute to be 0, which is presumably a missing entry
        #print("Entries with incorrect bouwjaar: ", len(funda_data[funda_data.bouwjaar == 0]))
        #print("Entries with incorrect oppervlakte: ", len(funda_data[funda_data.perceelOppervlakte == 0]))
        #print("Entries with incorrect totale oppervlakte: ", len(funda_data[funda_data.oppervlakte == 0]))
        #print("Entries with incorrect prijs: ",len(funda_data[funda_data.koopPrijs == 0]))
        #print("Entries with incorrect kamers: ",len(funda_data[funda_data.aantalKamers == 0]))

        # Only take the years with 1 year and not a range
        funda_data = funda_data[funda_data['bouwjaar'].apply(lambda x: str(x).isdigit())]
        #print(funda_data.pop("bouwjaar"))

        # Deleting outliers in price
        funda_data = funda_data.drop(funda_data[(funda_data['koopPrijs']>3000000)].index)

        # Create variable verkoopduur (sellingtime)
        funda_data['publicatieDatum'] = pd.to_datetime(funda_data['publicatieDatum'])
        funda_data['datum_ondertekening'] = pd.to_datetime(funda_data['datum_ondertekening'])
        funda_data['verkoopduur'] = (funda_data['datum_ondertekening'] - funda_data['publicatieDatum']).dt.days
        #print(funda_data.head)

        # Remove negative values in verkoopduur (sellingtime)
        funda_data = funda_data.query("~(verkoopduur < 1)")
        #print(funda_data.head)

        # check for number of rows in DataFrame
        numOfRows = funda_data.shape[0]
        print('Number of rows in cleaned dataset : ' , numOfRows)

        # check DataFrame and save as CSV
        #print(funda_data)
        #export_csv = funda_data.to_csv (r'/home/pi/RSL/housing_data_clean.csv', index = None, header=True)

        return funda_data
    
