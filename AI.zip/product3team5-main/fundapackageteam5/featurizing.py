import pandas as pd
import numpy as np
import seaborn as sn
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn import preprocessing

class Featurizer(object):

    def _init_(self):
      pass

    def featurizing(self,funda_data):
        # save filepath to variable for easier access
        #funda_file_path = '/home/pi/RSL/housing_data_clean.csv'
        # read the data and store data in DataFrame
        #funda_data = pd.read_csv(funda_file_path) 

        # check all columns in DataFrame
        #print(funda_data.columns)

        funda_data = funda_data.sort_values(['globalId'])
        # copy the variables that need transforming 
        funda_data['categorieObjectTransform'] = funda_data['categorieObject']
        funda_data['soortWoningTransform'] = funda_data['soortWoning']
        funda_data['postcodeTransform'] = funda_data['postcode']

        # categorial variables transforming to numbers to use in the model #to featurizing
        le = preprocessing.LabelEncoder()
        funda_data['categorieObjectTransform'] = le.fit_transform(funda_data['categorieObjectTransform'])
        funda_data['soortWoningTransform'] = le.fit_transform(funda_data['soortWoningTransform'])
        funda_data['postcodeTransform'] = le.fit_transform(funda_data['postcodeTransform'])
        #print(funda_data)

        #Dropping variables which will not be used in the pipeline
        featurized_data = funda_data.drop(['publicatieDatum', 'datum_ondertekening', 'postcode', 
        'soortWoning', 'categorieObject', 'volledigeOmschrijving'], axis=1).reset_index(drop=True)
        #print(featurized_data)
        return featurized_data
