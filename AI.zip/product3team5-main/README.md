# product3team5

Hello Riccardo, 

First of all, thank you for teaching us more about the possibilities of Python and building machine learning models. We have the basic information stored in this file. We hope you can find everything in our package. 
The link to join the Trello board if needed: https://trello.com/invite/b/t7iaDLqA/09386ee5215b2aad54ccd38789203bd1/funda-module-3

We only used the Funda csv file, it is available on Brightspace.
We tested the installing of the package in a conda environment, this should work for you as well. The python version which is required is 3.8.5

Explanation about the configuration file (conf.json):
1.	You need to change the base folder to make sure you use the correct path, and make sure that the file name is correct. The base folder should be the "raw" folder in the "data" folder.
2.	If it is the first time you are running it, you are not able to use the “reload clean data” function. Later on you can make use of this when you want to run it again. 
3.	You can select the target, the names are: "koopPrijs" for selling price (or listing price) and "verkoopduur" for selling time.
4.	You can select your model type: rf is a random forest and nn is a neural network, both models work for both variables (so 4 different options in total).
5.  If preferred, you can indicate wether or not you want to perform the hypertuning process (using the "perform_hypertuning" variable). If set to False, the chosen model will run using the optimal parameter combinations found by us. 
6.	If this option is set to True, you can change the parameters for both the model types, the parameters will be used for hypertuning and the best combination will automatically be used for the final model. ***WARNING***: This process can take very long depending on your chosen parameters. You can also use a parameter combination which is not accurate in order to save time, but which demonstrates the purpose. 
7.  Finally, if preferred, you can alter the optimal parameter settings, which can then be used to run the model without performing hypertuning.
8.  Plots are stored in the "models" folder.

In order to run, just enter the following in your command line:

python .\run\run.py

Use of notebooks:
We used the notebooks to share our personal progress regarding 1 model per person. This is what we made in the first week of the module to get a basic understanding of making a model. Afterwards we worked in the package with each other. 

kind regards, 

Team High 5, 
Agnesa, Aron, Koen & Marciano 
