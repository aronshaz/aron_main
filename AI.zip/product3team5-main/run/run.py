import json
import datetime
import pandas as pd  
import numpy as np
import shutil
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2' #This disables Tensorflow warning messages. If preferred, you can remove this
#import pyarrow
import seaborn as sn
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn import preprocessing
from pathlib import Path
from sklearn.utils import shuffle
from sklearn.neighbors import KNeighborsClassifier
from sklearn import linear_model, preprocessing, datasets, svm, metrics
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.ensemble import RandomForestRegressor
import tensorflow as tf
import statistics
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Flatten
import warnings 
warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
from plot_keras_history import plot_history

from fundapackageteam5.load_data import DataLoader
from fundapackageteam5.clean_data import DataCleaner
from fundapackageteam5.featurizing import Featurizer
from fundapackageteam5.hypertuning import Hypertuner
from fundapackageteam5.validation_utils import DataPartitioner

def main():

    #Set start time of run
    run_id_start_time = datetime.datetime.now()
    print(f"Starting with run at {run_id_start_time}")
    # Read config file
    with open('./run/conf.json', 'r') as f:
        conf = json.load(f)
    #Create dir for run
    run_folder = os.path.join(conf['base_folder'], 'run_' + run_id_start_time.strftime("%Y%m%d_%H%M"))
    #Create output folders for run
    for i in ['clean', 'logs', 'prepared', 'models', 'predictions']:
        Path(run_folder, i).mkdir(parents=True, exist_ok=True)
    #Ensuring the raw folder exists
    assert os.path.exists(os.path.join(conf['base_folder'], 'raw')), "Unable to locate raw data folder"
    #Log the config file
    with open(os.path.join(run_folder, 'logs', 'run_config.json'), 'w') as f:
        json.dump(conf, f)

    # Checking if data needs to be cleaned or loaded from previous run
    reload_clean_data = False
    try:
        reload_clean_data = conf['loading_params']['reload_clean_data']
    except KeyError:
        pass

    if reload_clean_data:
        print('Attempting to load previously cleaned data')
        try:
            #Finding latest run
            runs = [x for x in os.listdir(conf['base_folder']) if x.startswith('run')]
            runs.sort()
            last_run = runs[-2]
            #Copying cleaned data from previous run
            shutil.copyfile(os.path.join(conf['base_folder'], last_run, 'clean', 'funda_data.feather'),
            os.path.join(conf['base_folder'], run_folder, 'clean', 'funda_data.feather'))
            #Loading cleaned data from previous run
            funda_data = pd.read_feather(os.path.join(run_folder, 'clean', 'funda_data.feather'))
            print('Previously cleaned data loaded successfully')
        except Exception as e:
            print(f'Loading previously cleaned data failed with error {e}.')

    if reload_clean_data is False:
        try:
            print('Loading and cleaning data')
            data_loader = DataLoader(conf['base_folder'] + '/raw', conf['raw_housing_file_name'])
            funda_data = data_loader.load_data()
            #Cleaning of data
            data_cleaner = DataCleaner()
            funda_data = data_cleaner.clean_data(funda_data)
            #Storing cleaned data
            funda_data.reset_index(drop=True).to_feather(os.path.join(run_folder, 'clean', 'funda_data.feather'))
            print('Data loaded and cleaned succesfully')
        except Exception as e:
            print(f'Cleaning data failed with error {e}.')

    #Create train and test sets
    validation_mapping = DataPartitioner().partition_data(funda_data)
    validation_mapping.to_feather(os.path.join(run_folder, 'prepared', 'validation_mapping.feather'))

    #Featurizing data
    featurized_data = Featurizer().featurizing(funda_data)
    featurized_data.to_feather(os.path.join(run_folder, 'prepared', 'features.feather'))

    #Hypertuning if preferred in config file to find optimal parameters
    train_set = featurized_data.merge(validation_mapping.query("test == False")[['globalId']])
    test_set = featurized_data.merge(validation_mapping.query("test == True")[['globalId']])
    print("Dataset ready to be hypertuned using cross-validation")

    if conf["training_params"]["perform_hypertuning"] is True:
        hypertuner_rf = Hypertuner(estimator = RandomForestRegressor(random_state=1234), 
        tuning_params=conf["training_params"]["hypertuning"]["RF_params"], 
        validation_mapping=validation_mapping)

        hypertuner_nn = Hypertuner(estimator = Sequential(), 
        tuning_params=conf["training_params"]["hypertuning"]["NN_params"], 
        validation_mapping=validation_mapping)
        
        if conf["training_params"]["model_type"] == "rf":
            param_combo, min_rmse = hypertuner_rf.tune_model(train_set, conf["training_params"]["target"], 
            conf["training_params"]["model_type"])
            print(f"Hypertuning completed. The best parameter combination is the following. Estimators: {param_combo['n_estimators']}, Max depth: {param_combo['max_depth']}")
            print(f"The average RMSE of this combination is {min_rmse}")

        elif conf["training_params"]["model_type"] == "nn":
            param_combo, min_rmse = hypertuner_nn.tune_model(train_set, conf["training_params"]["target"], 
            conf["training_params"]["model_type"])
            print(f"Hypertuning completed. The best parameter combination is the following. Batch: {param_combo[0]}, Epochs: {param_combo[1]}")
            print(f"The average RMSE of this combination is {min_rmse}")

    #Loading optimal parameters if not performing hypertuning
    elif conf["training_params"]["perform_hypertuning"] is False:
        if conf["training_params"]["model_type"] == "rf":
            param_combo = conf["validation_params"]["optimal_rf_params"]
            print(f"Will not perform hypertuning. The parameters which will be used for this run are: Estimators: {param_combo['n_estimators']}, Max depth: {param_combo['max_depth']}")
            
        elif conf["training_params"]["model_type"] == "nn":
            param_combo = (conf["validation_params"]["optimal_nn_params"]["batch_size"], conf["validation_params"]["optimal_nn_params"]["epochs"])
            print(f"Will not perform hypertuning. The parameters which will be used for this run are: Batch: {param_combo[0]}, Epochs: {param_combo[1]}")

    #Running the model using the optimal parameters

    y_train = train_set[conf["training_params"]["target"]]
    X_train = train_set.drop(['globalId', conf["training_params"]["target"]],axis=1)
    y_test = test_set[conf["training_params"]["target"]]
    X_test = test_set.drop(['globalId', conf["training_params"]["target"]],axis=1)

    if conf["training_params"]["model_type"] == "rf":
        print(f"Starting final run with optimal parameters for RF")
        final_rf_estimator = RandomForestRegressor()
        final_rf_estimator = final_rf_estimator.set_params(**param_combo)
        final_rf_estimator.fit(X=X_train, y = y_train)
        y_pred = final_rf_estimator.predict(X_test)
        np.save(os.path.join(run_folder, 'predictions', 'predictions'), y_pred)

    elif conf["training_params"]["model_type"] == "nn":
        print(f"Starting final run with optimal parameters for NN")
        final_nn_estimator = Sequential()
        X_train = np.asarray(X_train).astype(np.float32)
        y_train = np.asarray(y_train).astype(np.float32)
        X_test = np.asarray(X_test).astype(np.float32)
        y_test = np.asarray(y_test).astype(np.float32)

        final_nn_estimator.add(Dense(128, input_dim=10, activation='relu'))  
        final_nn_estimator.add(Dense(256, activation='relu'))
        final_nn_estimator.add(Dense(256, activation='relu'))
        final_nn_estimator.add(Dense(1, activation='linear'))
        final_nn_estimator.compile(loss="mean_squared_error", optimizer="adam", 
        metrics=[tf.keras.metrics.RootMeanSquaredError()])
        history = final_nn_estimator.fit(X_train, y_train, 
        batch_size=param_combo[0], epochs=param_combo[1], validation_data=(X_test, y_test)).history
        y_pred = final_nn_estimator.predict(X_test)
        np.save(os.path.join(run_folder, 'predictions', 'predictions'), y_pred)

    rmse = mean_squared_error(y_test, y_pred, squared=False)
    print(f"The RMSE for the final run is {rmse}")

    #Evaluation and plotting

    #Actual vs Predicted
    plt.scatter(y_test, y_pred)
    plt.xlabel("Actual")
    plt.ylabel("Predicted")
    plt.title("Actual vs Predicted")
    plt.savefig(os.path.join(run_folder, 'models', 'actual_vs_predicted'))
    plt.show()
    # Residuals 
    sn.residplot(y_test, y_pred)
    plt.xlabel("Predicted")
    plt.ylabel("Residuals")
    plt.title("Residual plot")
    plt.savefig(os.path.join(run_folder, 'models', 'residuals'))
    plt.show()

    if conf["training_params"]["model_type"] == "rf":
        # Relative residual plot
        sn.residplot(y_test, (y_test-y_pred)/y_test)
        plt.xlabel("Predicted")
        plt.ylabel("Relative residuals")
        plt.title("Relative residual plot")
        plt.savefig(os.path.join(run_folder, 'models', 'relative_residuals'))
        plt.show()
    else:
        plot_history(history)
        plt.savefig(os.path.join(run_folder, 'models', 'accuracy_log'))
        plt.show()
        plt.close()

if __name__ == "__main__":
    main()

