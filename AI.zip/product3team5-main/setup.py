from setuptools import setup, find_namespace_packages, find_packages

setup(
    name='fundapackageteam5',
    version=1.0,
    description="Funda package for team 5",
    packages=find_packages(include=['fundapackageteam5', 'fundapackageteam5.*']),
    package_dir={'fundapackageteam5': 'fundapackageteam5'},
    include_package_data=True,
    install_requires=[
        'pandas',
        'numpy',
        'sklearn',
        'tensorflow',
        'keras',
        'plot_keras_history',
        'pyarrow',
        'seaborn',
        'statistics',
        'datetime',
        'pathlib'

    ],
python_requires='==3.8.5' 
)
