#import tensorflow as tf 
import keras
from keras.layers import Dense 
from keras.models import Sequential
import pandas as pd
import numpy as np
import matplotlib
import sklearn
from sklearn.utils import shuffle
from sklearn.neighbors import KNeighborsClassifier
from sklearn import linear_model, preprocessing, datasets, svm, metrics
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.ensemble import RandomForestRegressor
from matplotlib import pyplot as plt
import seaborn as sb
import matplotlib.pyplot as plt
import warnings 
warnings.filterwarnings('ignore')
warnings.filterwarnings('ignore', category=DeprecationWarning)
#import tensorflow_docs as tfdocs
#import tensorflow_docs.plots
#import tensorflow_docs.modeling
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Flatten
from plot_keras_history import plot_history
"""
"""
## RANDOM FOREST
# Load data
funda_data = pd.read_csv("housing_data.csv") 

# Filter rows with missing values
funda_data = funda_data.dropna(axis=0)

# Choose target and features
y = funda_data.koopPrijs
funda_features = ['aantalKamers', 'aantalBadkamers', 'perceelOppervlakte', 'oppervlakte']
X = funda_data[funda_features]

# split data into training and validation data, for both features and target
# The split is based on a random number generator. Supplying a numeric value to
# the random_state argument guarantees we get the same split every time we
# run this script.
train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.2, random_state = 1)
forest_model = RandomForestRegressor(random_state=1)
forest_model.fit(train_X, train_y)
preds = forest_model.predict(test_X)
print(preds)
print(test_y)
print(mean_absolute_error(test_y, preds))

## NEURAL NETWORK

# Load dataset
funda_data = pd.read_csv("housing_data.csv", engine='python', encoding='utf-8', error_bad_lines=False) 
funda_data = funda_data.dropna(axis=0)

funda_data['publicatieDatum'] = pd.to_datetime(funda_data['publicatieDatum'])
funda_data['datum_ondertekening'] = pd.to_datetime(funda_data['datum_ondertekening'])
funda_data['selling_time'] = (funda_data['datum_ondertekening'] - funda_data['publicatieDatum']).dt.days
print(sum(funda_data['selling_time'])/len(funda_data['selling_time']))
#print(funda_data.info())
#print(funda_data.head())


# Compute correlation
correlation_matrix = funda_data.corr()

# Display correlation plot
fig = plt.figure(figsize = (8,8))
sb.heatmap(correlation_matrix, vmax = 0.8, vmin=-0.8, square = True, cmap='RdBu_r')
plt.show()
"""
"""
def oneHotEncode(df,colNames):
    for col in colNames:
        if(df[col].dtype == np.dtype('object')):
            dummies = pd.get_dummies(df[col],prefix=col)
            df = pd.concat([df,dummies],axis=1)

            #drop the encoded column
            df.drop([col],axis = 1 , inplace=True)
    return df

funda_cat = ['soortWoning', 'bouwjaar', 'energielabelKlasse']

#print('There were {} columns before encoding categorical features'.format(funda_data.shape[1]))
funda_data = oneHotEncode(funda_data, funda_cat)
#print('There are {} columns after encoding categorical features'.format(funda_data.shape[1]))

# Choose target and features

n_train = round(funda_data.shape[0] * 0.8)
x_train = funda_data[:n_train]
x_test = funda_data[n_train:]

y_train = x_train['selling_time']
x_train.drop(['selling_time', 'publicatieDatum', 'postcode', 'volledigeOmschrijving', 'soortWoning', 'categorieObject', 'bouwjaar',
'kantoor_naam_MD5hash', 'energielabelKlasse', 'datum_ondertekening', 'globalId', 'globalId.1'], axis = 1, inplace = True)

y_test = x_test['selling_time']
x_test.drop(['selling_time', 'publicatieDatum', 'postcode', 'volledigeOmschrijving', 'soortWoning', 'categorieObject', 'bouwjaar',
'kantoor_naam_MD5hash', 'energielabelKlasse', 'datum_ondertekening', 'globalId', 'globalId.1'], axis = 1, inplace = True)

x_train = np.asarray(x_train).astype(np.float32)
x_test = np.asarray(x_test).astype(np.float32)
y_train = np.asarray(y_train).astype(np.float32)
y_test = np.asarray(y_test).astype(np.float32)

# creating model
model = Sequential()
model.add(Dense(128, input_dim=6, activation='relu'))
model.add(Dense(256, activation='relu'))
model.add(Dense(256, activation='relu'))
model.add(Dense(1, activation='linear'))

# compile and fit model
model.compile(loss="mean_squared_error", optimizer="adam", metrics=['mean_absolute_error'])
model.summary()

# Define how to name the files
checkpoint_name = 'Weights-{epoch:03d}--{val_loss:.5f}.hdf5' 

# Instantiate the checkpoint system
checkpoint = ModelCheckpoint(checkpoint_name, monitor='val_loss', verbose = 1, save_best_only = True, mode ='auto')
callbacks_list = [checkpoint]

history = model.fit(x_train, y_train, batch_size=16, epochs=20, validation_data=(x_test, y_test), callbacks=callbacks_list).history

weights_file = 'Weights-013--2779.53003.hdf5' 
 
# Load the parameters of the models (weights & bias)
model.load_weights(weights_file)
model.compile(loss='mean_squared_error', optimizer='adam', metrics=['mean_squared_error'])

prediction = model.predict(x_test)

plot_history(history)
plt.show()
plot_history(history, path="standard.png")
plt.close()

plt.figure()
plt.scatter(prediction, y_test, alpha=0.2)
plt.xlabel('Predictions')
plt.ylabel('True Values')
lims = [0, 300]
plt.xlim(lims)
plt.ylim(lims)
_ = plt.plot(lims, lims)
plt.show()

import pandas as pd
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from sklearn.ensemble import RandomForestRegressor

#######################################################################################################################################
# Path of the file to read
file_path = "Melbourne_housing_FULL.csv"
home_data = pd.read_csv(file_path)

y = home_data.Price

feature_columns = ['LotArea', 'YearBuilt', '1stFlrSF', '2ndFlrSF', 'FullBath', 'BedroomAbvGr', 'TotRmsAbvGrd']
X = home_data[feature_columns]

train_X, test_X, train_y, test_y = train_test_split(X, y, random_state = 1)

# Specify the model
iowa_model = DecisionTreeRegressor(random_state=1)

# Fit iowa_model with the training data.
iowa_model.fit(train_X, train_y)

# Predict with all validation observations
test_predictions = iowa_model.predict(test_X)

# print the top few validation predictions
print(test_predictions)
# print the top few actual prices from validation data
print(test_y)

test_mae = mean_absolute_error(test_y, test_predictions)

# uncomment following line to see the validation_mae
print(test_mae)

def get_mae(max_leaf_nodes, train_X, val_X, train_y, val_y):
    model = DecisionTreeRegressor(max_leaf_nodes=max_leaf_nodes, random_state=0)
    model.fit(train_X, train_y)
    preds_val = model.predict(val_X)
    mae = mean_absolute_error(val_y, preds_val)
    return(mae)


candidate_max_leaf_nodes = [5, 25, 50, 100, 250, 500]
# Write loop to find the ideal tree size from candidate_max_leaf_nodes
scores = {leaf_size: get_mae(leaf_size, train_X, val_X, train_y, val_y) for leaf_size in candidate_max_leaf_nodes}
best_tree_size = min(scores, key=scores.get)

final_model = DecisionTreeRegressor(max_leaf_nodes=best_tree_size, random_state=1)

# fit the final model
final_model.fit(X, y)


# Load data
melbourne_file_path = "Melbourne_housing_FULL.csv"
melbourne_data = pd.read_csv(melbourne_file_path) 

# Filter rows with missing values
melbourne_data = melbourne_data.dropna(axis=0)
# Choose target and features
y = melbourne_data.Price
melbourne_features = ['Rooms', 'Bathroom', 'Landsize', 'BuildingArea', 'YearBuilt', 'Lattitude', 'Longtitude']
X = melbourne_data[melbourne_features]

# split data into training and validation data, for both features and target
# The split is based on a random number generator. Supplying a numeric value to
# the random_state argument guarantees we get the same split every time we
# run this script.
train_X, test_X, train_y, test_y = train_test_split(X, y, random_state = 1)

forest_model = RandomForestRegressor(random_state=1)
forest_model.fit(train_X, train_y)


melb_preds = forest_model.predict(test_X)

print(melb_preds)

print(test_y)
print(mean_absolute_error(test_y, melb_preds))

#############################################################################################################################################
# Part 1
data = pd.read_csv("student-mat.csv", sep=";")

data = data[["G1", "G2", "G3", "studytime", "failures", "absences"]]

predict = "G3"

x = np.array(data.drop([predict], 1))
y = np.array(data[predict])

x_train, x_test, y_train, y_test = sklearn.model_selection.train_test_split(x, y, test_size = 0.1)

linear = linear_model.LinearRegression()

linear.fit(x_train, y_train)

acc = linear.score(x_test, y_test)

#print(acc)
#print(linear.coef_)
#print(  linear.intercept_)

predictions = linear.predict(x_test)

for x in range(len(predictions)):
    print(predictions[x], x_test[x], y_test[x])


# Part 2: K-Nearest Neighbors

data = pd.read_csv("car.data")

le = preprocessing.LabelEncoder()
buying = le.fit_transform(list(data["buying"]))
maint = le.fit_transform(list(data["maint"]))
door = le.fit_transform(list(data["door"]))
persons = le.fit_transform(list(data["persons"]))
lug_boot = le.fit_transform(list(data["lug_boot"]))
safety = le.fit_transform(list(data["safety"]))
clss = le.fit_transform(list(data["class"]))

predict = "class"

X = list(zip(buying, maint, door, persons, lug_boot, safety))
y = list(clss)

x_train, x_test, y_train, y_test = sklearn.model_selection.train_test_split(X, y, test_size = 0.1)

model = KNeighborsClassifier(n_neighbors=5)

model.fit(x_train, y_train)
acc = model.score(x_test, y_test)
print(acc)

predicted = model.predict(x_test)
names = ["unacc", "acc", "good", "vgood"]

for x in range(len(predicted)):
    print("Predicted:", names[predicted[x]], "Data:", x_test[x], "Actual:", names[y_test[x]])
    n = model.kneighbors([x_test[x]], 9, True)
    print(n)


# Part 3: Support Vector Machines
cancer = datasets.load_breast_cancer()

x = cancer.data
y = cancer.target

x_train, x_test, y_train, y_test = sklearn.model_selection.train_test_split(x, y, test_size = 0.2)

#print(x_train, y_train)
classes = ['malignant', 'benign']

#clf = svm.SVC(kernel="linear")
clf = KNeighborsClassifier(n_neighbors=7)

clf.fit(x_train, y_train)

y_pred = clf.predict(x_test)

accuracy = metrics.accuracy_score(y_test, y_pred)

print(accuracy)


# NN from scratch part 1
inputs = [[1.0, 2.0, 3.0, 2.5],
          [2.0, 5.0, -1.0, 2.0],
          [-1.5, 2.7, 3.3, -0.8]]

weights = [[0.2, 0.8, -0.5, 1.0],
           [0.5, -0.91, 0.26, -0.5],
           [-0.26, -0.27, 0.17, 0.87]]

biases = [2.0, 3.0, 0.5]

weights2 = [[0.1, -0.14, 0.5],
           [-0.5, 0.12, -0.33],
           [-0.44, 0.73, -0.13]]

biases2 = [-1, 2, -0.5]

layer1_outputs = np.dot(inputs, np.array(weights).T) + biases
layer2_outputs = np.dot(layer1_outputs, np.array(weights2).T) + biases2

print(layer2_outputs)

# NN from scratch Part 2
print(np.random.seed(0))

X = [[1, 2, 3, 2.5],
     [2.0, 5.0, -1.0, 2.0],
     [-1.5, 2.7, 3.3, -0.8]]


class Layer_Dense:
    def __init__(self, n_inputs, n_neurons):
        self.weights = 0.10 * np.random.randn(n_inputs, n_neurons)
        self.biases = np.zeros((1, n_neurons))
    def forward(self, inputs):
        self.output = np.dot(inputs, self.weights) + self.biases

layer1 = Layer_Dense(4,5)
layer2 = Layer_Dense(5,2)

layer1.forward(X)
#print(layer1.output)
layer2.forward(layer1.output)
print(layer2.output)

# number of wine classes
classifications = 3

# load dataset
dataset = np.loadtxt('wine.csv', delimiter=",")

# split dataset into sets for testing and training
X = dataset[:,1:14]
Y = dataset[:,0:1]
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=5)

# convert output values to one-hot
y_train = keras.utils.to_categorical(y_train-1, classifications)
y_test = keras.utils.to_categorical(y_test-1, classifications)


# creating model
model = Sequential()
model.add(Dense(10, input_dim=13, activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(6, activation='relu'))
model.add(Dense(6, activation='relu'))
model.add(Dense(4, activation='relu'))
model.add(Dense(2, activation='relu'))
model.add(Dense(classifications, activation='softmax'))

# compile and fit model
model.compile(loss="mean_squared_error", optimizer="adam", metrics=['accuracy'])
model.fit(x_train, y_train, batch_size=15, epochs=500, validation_data=(x_test, y_test))