import tensorflow as tf 
import keras
from keras.layers import Dense 
from keras.models import Sequential
import pandas as pd
import numpy as np
import matplotlib
import sklearn
from sklearn import linear_model, preprocessing, datasets, svm, metrics
from sklearn.metrics import mean_absolute_error
from matplotlib import pyplot as plt
import seaborn as sb
import matplotlib.pyplot as plt
import warnings 
warnings.filterwarnings('ignore')
warnings.filterwarnings('ignore', category=DeprecationWarning)
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Flatten

#funda_file_path = '/home/pi/RSL/product3team5-main/data/raw/housing_data.csv'

# read the data and store data in DataFrame
funda_data = pd.read_csv('/home/pi/RSL/product3team5-main/data/raw/housing_data.csv', engine='python', encoding='utf-8', error_bad_lines=False) 

# Make new clean DataFrame to work with all needed columns
funda_data_clean = funda_data[['globalId', 'publicatieDatum', 'postcode', 'koopPrijs',
       'soortWoning', 'categorieObject', 'bouwjaar',
       'indTuin', 'perceelOppervlakte', 'aantalKamers', 
       'aantalBadkamers', 'oppervlakte', 
       'datum_ondertekening']].copy()

# remove all NaN from table 
funda_data_clean = funda_data_clean.dropna()

#Split data into trian & test 
n_train = round(funda_data_clean.shape[0] * 0.8)
x_train = funda_data_clean[:n_train]
x_test = funda_data_clean[n_train:]

y_train = x_train['koopPrijs']
x_train.drop(['koopPrijs', 'postcode', 'categorieObject', 'bouwjaar', 'soortWoning',
'publicatieDatum', 'datum_ondertekening', 'globalId'], axis = 1, inplace = True)

y_test = x_test['koopPrijs']
x_test.drop(['koopPrijs', 'postcode', 'categorieObject', 'bouwjaar', 'soortWoning',
'publicatieDatum', 'datum_ondertekening', 'globalId'], axis = 1, inplace = True)

###exploring correlations
correlation_matrix = funda_data_clean.corr()

# Open figure container
fig = plt.figure(figsize = (8,8))
# Make color heatmap (library seaborn)
sb.heatmap(correlation_matrix, vmax = 0.8, vmin=-0.8, square = True, cmap='RdBu_r')
#Display plot
plt.show()

#Make the neural network, Initiate a sequential model (i.e., no recurrence)
model = Sequential()
model.add(Dense(128, input_dim=5, activation='relu'))
model.add(Dense(256, activation='relu'))
model.add(Dense(256, activation='relu'))
model.add(Dense(1, activation='linear'))

model.compile(loss="mean_squared_error", optimizer="adam", metrics=['mean_absolute_error'])
model.summary()

model.fit(x_train, y_train, batch_size=16, epochs=20, validation_data=(x_test, y_test))

prediction = model.predict(x_test)
