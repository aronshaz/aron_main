#%%
import pandas as pd
import numpy as np
import seaborn as sn
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn import metrics
from sklearn.utils import check_arrays


# save filepath to variable for easier access
funda_file_path = '/home/pi/RSL/housing_data.csv'
# read the data and store data in DataFrame
funda_data = pd.read_csv(funda_file_path) 

# find all columns in DataFrame
# print(funda_data.columns)

# Find the best Features with highest correlation
#corrMatrix = funda_data.corr()
#sn.heatmap(corrMatrix, annot=True)
#plt.show()

# Make new clean DataFrame to work with best variables
fd2 = funda_data[['globalId', 'koopPrijs', 'oppervlakte', 'aantalKamers']].copy()
#print(fd2.head())

# remove NAN (cleaning)
fd2 = fd2.dropna()

# selecting the prediction target
y = fd2.koopPrijs

# selecting Features
funda_features = ['oppervlakte', 'aantalKamers']
X = fd2[funda_features]

# check Featurs 
#print(X.head())

# Define model - Specify a number for random_state to ensure same results each run
funda_model = DecisionTreeRegressor(random_state=1)

# Fit model
funda_model.fit(X, y)  

# Predictions
#print("Making predictions for the following 5 houses:")
#print(X.head())
#print("The predictions are")
#print(funda_model.predict(X.head())) 

# Calculate the MAE with sklearn #83230.63706425703
#predicted_prices = funda_model.predict(X)
#print(mean_absolute_error(y, predicted_prices))

# Calculate the MAE with code #89909.08678759805
# split data into training and validation data, for both features and target
train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=.20, random_state = 0)
# Define model
funda_model = DecisionTreeRegressor()
# Fit model
funda_model.fit(train_X, train_y)

# get predicted prices on validation data
test_predictions = funda_model.predict(test_X)
#print(mean_absolute_error(test_y, test_predictions))

# MAE with Random Forest #88792.352624718
forest_model = RandomForestRegressor(random_state=1)
forest_model.fit(train_X, train_y)
funda_randomf = forest_model.predict(test_X)
funda_randomf2 = forest_model.predict(train_X)
#print(mean_absolute_error(test_y, funda_preds))

# RMSE with Random Forest 
#print('Train set: Mean Absolute Error:', metrics.mean_absolute_error(train_y, funda_randomf2)) #83970.40159728179
#print('Test set: Mean Absolute Error:', metrics.mean_absolute_error(test_y, funda_randomf)) #88792.352624718
#print('Train set: Mean Squared Error:', metrics.mean_squared_error(train_y, funda_randomf2)) #17414267203.807045
#print('Test set: Mean Squared Error:', metrics.mean_squared_error(test_y, funda_randomf)) #21888521018.892467
#print('Train set: Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(train_y, funda_randomf2))) #131963.12819801993
#print('Test set: Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(test_y, funda_randomf))) #147947.69690296793

# Calculate MAPE
mean_absolute_percentage_error(y_true, y_pred)


# Plot price vs predicted price train set
plt.scatter(train_y, forest_model.predict(train_X))
plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")
plt.title("Actual Price vs Predicted Price train set")
plt.show()

# Plot price vs predicted price test set
plt.scatter(test_y, forest_model.predict(test_X))
plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")
plt.title("Actual Price vs Predicted Price test set")
plt.show()

# Residual plot train 
sn.residplot(train_y, forest_model.predict(train_X))
plt.xlabel("Predicted prices")
plt.ylabel("Residuals")
plt.title("Residual plot")
plt.show()

# Residuals plot test
sn.residplot(test_y, forest_model.predict(test_X))
plt.xlabel("Predicted prices")
plt.ylabel("Residuals")
plt.title("Residual plot")
plt.show()

# %%

