import psycopg2
import pandas as pd

con = psycopg2.connect("dbname=test user=pi")
cur = con.cursor()

cur.execute("DROP TABLE Funda_House CASCADE;")
cur.execute("DROP TABLE Gemeente CASCADE;")
cur.execute("DROP TABLE PostcodeTB CASCADE;")
cur.execute("DROP TABLE Provincie CASCADE;")
cur.execute("DROP TABLE Landdeel CASCADE;")
cur.execute("DROP TABLE Distance CASCADE;")
cur.execute("DROP TABLE Population CASCADE;")
cur.execute("DROP TABLE Property CASCADE;")

cur.execute("SET datestyle = dmy;")
cur.execute("SET CLIENT_ENCODING TO 'utf8';")

#-- Create Funda_House table
cur.execute("CREATE TABLE Funda_House( \
GlobalID text PRIMARY KEY, \
PublicatieDatum TIMESTAMP WITHOUT TIME ZONE, \
Postcode text, \
KoopPrijs text, \
VolledigeOmschijving text, \
SoortWoning text, \
CategorieObject text, \
Bouwjaar varchar(20), \
IndTuin boolean, \
PerceelOppervlakte text, \
KantoorNaam text, \
AantalKamers text, \
AantalBadkamers text, \
EnergielabelKlasse text, \
GlobalID_1 text, \
Oppervlakte text, \
DatumOndertekening TIMESTAMP WITHOUT TIME ZONE \
);")
with open('/home/pi/RSL/FundaAssignment/Funda_Datasets/Funda_House.csv') as t1:
    cur.copy_expert("COPY Funda_House FROM STDIN CSV HEADER", t1)

cur.execute("ALTER TABLE Funda_House ADD timeOnMarket interval;")
cur.execute("UPDATE Funda_House SET timeOnMarket = DatumOndertekening - PublicatieDatum;")

#-- Removing 'NULL' from KoopPrijs, PerceelOppervlakte, AantalKamers, AantalBadkamers, Oppervlakte
cur.execute("UPDATE Funda_House SET KoopPrijs = '0' WHERE KoopPrijs = 'NULL';")
cur.execute("UPDATE Funda_House SET PerceelOppervlakte = '0' WHERE PerceelOppervlakte = 'NULL' ;")
cur.execute("UPDATE Funda_House SET AantalKamers = '0' WHERE AantalKamers = 'NULL';")
cur.execute("UPDATE Funda_House SET AantalBadkamers = '0' WHERE AantalBadkamers = 'NULL';")
cur.execute("UPDATE Funda_House SET Oppervlakte = '0' WHERE Oppervlakte = 'NULL';")

#-- Change from text to interger for KoopPrijs, PerceelOppervlakte, AantalKamers, AantalBadkamers, Oppervlakte
cur.execute("ALTER TABLE Funda_House ALTER COLUMN KoopPrijs TYPE integer USING (KoopPrijs::integer); ")
cur.execute("ALTER TABLE Funda_House ALTER COLUMN PerceelOppervlakte TYPE integer USING (PerceelOppervlakte::integer); ")
cur.execute("ALTER TABLE Funda_House ALTER COLUMN AantalKamers TYPE integer USING (AantalKamers::integer); ")
cur.execute("ALTER TABLE Funda_House ALTER COLUMN AantalBadkamers TYPE integer USING (AantalBadkamers::integer); ")
cur.execute("ALTER TABLE Funda_House ALTER COLUMN Oppervlakte TYPE integer USING (Oppervlakte::integer); ")

#-- Delete the postcode from the Funda data that is incomplete (only 4 instead of 6)
cur.execute("DELETE FROM Funda_House WHERE length(postcode)<6;")

#-- Create Postcode table
cur.execute("CREATE TABLE PostcodeTB( \
Postcode text PRIMARY KEY, \
GemeenteCode text \
);")
with open('/home/pi/RSL/FundaAssignment/CBS_Datasets/Postcode.csv') as t2:
    cur.copy_expert("COPY PostcodeTB FROM STDIN CSV HEADER DELIMITER ';'", t2)

#-- Create Gemeente table
cur.execute("CREATE TABLE Gemeente( \
GemeenteCode text PRIMARY KEY, \
ProvincieCode text, \
GemeenteNaam text \
);")
with open('/home/pi/RSL/FundaAssignment/CBS_Datasets/Gemeente.csv') as t3:
    cur.copy_expert("COPY Gemeente FROM STDIN CSV HEADER DELIMITER ','", t3)

#-- Create Provincie table
cur.execute("CREATE TABLE Provincie( \
ProvincieCode text PRIMARY KEY, \
LanddeelCode text, \
ProvincieNaam text \
);")
with open('/home/pi/RSL/FundaAssignment/CBS_Datasets/Provincie.csv') as t4:
    cur.copy_expert("COPY Provincie FROM STDIN CSV HEADER DELIMITER ';'", t4)

#-- Create Landdeel table
cur.execute("CREATE TABLE Landdeel( \
LanddeelCode text PRIMARY KEY, \
ProvincieNaam text \
);")
with open('/home/pi/RSL/FundaAssignment/CBS_Datasets/Landdeel.csv') as t5:
    cur.copy_expert("COPY Landdeel FROM STDIN CSV HEADER DELIMITER ';'", t5)

#-- Create Distance table
cur.execute("CREATE TABLE Distance( \
DisID TEXT PRIMARY KEY, \
GemeenteCode TEXT, \
AfstandTotHuisartsenpraktijk NUMERIC(2,1), \
AfstandTotGroteSupermarkt NUMERIC(2,1), \
AfstandTotKinderdagverblijf NUMERIC(2,1), \
AfstandTotSchool NUMERIC(2,1), \
AfstandTotRestaurant NUMERIC(2,1), \
AfstandTotTreinstation NUMERIC(3,1), \
FOREIGN KEY(GemeenteCode) REFERENCES Gemeente(GemeenteCode) \
);")
with open('/home/pi/RSL/FundaAssignment/CBS_Datasets/Distance.csv') as t6:
    cur.copy_expert("COPY Distance FROM STDIN CSV HEADER DELIMITER ';'", t6)

#-- Create Population table
cur.execute("CREATE TABLE Population( \
PopID TEXT PRIMARY KEY, \
GemeenteCode TEXT, \
AantalInwoners INT, \
Mannen INT, \
Vrouwen INT, \
Jaar0tot15 INT, \
jaar15tot25 INT, \
jaar25tot45 INT, \
jaar45tot65 INT, \
jaar65ofouder INT, \
Bevolkingsdichtheid INT, \
GemiddeldInkomenPerInwoner NUMERIC(3,1), \
FOREIGN KEY(GemeenteCode) REFERENCES Gemeente(GemeenteCode) \
);")
with open('/home/pi/RSL/FundaAssignment/CBS_Datasets/Population.csv') as t7:
    cur.copy_expert("COPY Population FROM STDIN CSV HEADER DELIMITER ';'", t7)

#-- Create Property table
cur.execute("CREATE TABLE Property( \
PropID TEXT PRIMARY KEY, \
GemeenteCode TEXT, \
Woningvoorraad INT, \
PercentageBewoond INT, \
TotaalDiefstalUitWoning INT, \
FOREIGN KEY(GemeenteCode) REFERENCES Gemeente(GemeenteCode) \
);")
with open('/home/pi/RSL/FundaAssignment/CBS_Datasets/Property.csv') as t8:
    cur.copy_expert("COPY Property FROM STDIN CSV HEADER DELIMITER ';'", t8)

#-- Set the Foreign Keys for the tables
cur.execute("ALTER TABLE PostcodeTB ADD CONSTRAINT GemeenteCode FOREIGN KEY (GemeenteCode) REFERENCES Gemeente(GemeenteCode);")
cur.execute("ALTER TABLE Gemeente ADD CONSTRAINT ProvincieCode FOREIGN KEY (ProvincieCode) REFERENCES Provincie(ProvincieCode);")
cur.execute("ALTER TABLE Provincie ADD CONSTRAINT LanddeelCode FOREIGN KEY (LanddeelCode) REFERENCES Landdeel(LanddeelCode);")

con.commit()
cur.close()
con.close()
