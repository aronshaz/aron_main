Literature query 2: Does the location (gemeente / provincie / landdeel) of the house influence the price or the sellingtime? (Koen)

-- Averages per Gemeente:

SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	gemeentenaam
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
GROUP BY
	gemeentenaam
ORDER BY
	gemeentenaam;


-- Average per Province:
SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	provincienaam
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
GROUP BY
	provincienaam
ORDER BY
	provincienaam;

--average per landdeel

SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	landdeelnaam
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN Landdeel ON landdeel. landdeelcode = provincie.landdeelcode
GROUP BY
	landdeelnaam
ORDER BY
	landdeelnaam;
