-- Does it take longer to sell houses in bigger cities?

-- Create needed table (gemeente x gemiddelede sellingtime x aantalinwoners)
CREATE TABLE L6_1 AS (
SELECT
	DatumOndertekening,
	PublicatieDatum,
	GemeenteNaam
FROM
	PostcodeTB
INNER JOIN Funda_House 
    ON Funda_House.Postcode = PostcodeTB.Postcode
INNER JOIN Gemeente
    ON Gemeente.GemeenteCode = PostcodeTB.GemeenteCode
);

-- Add time on market value
ALTER TABLE L6_1
ADD COLUMN TimeOnMarket interval
;

UPDATE L6_1
SET TimeOnMarket = DatumOndertekening - PublicatieDatum
;

-- Create other table to combine
CREATE TABLE L6_2 AS (
SELECT
	AantalInwoners,
	GemeenteNaam
FROM
	Gemeente
INNER JOIN Population 
    ON Population.GemeenteCode = Gemeente.GemeenteCode
ORDER BY AantalInwoners
);

-- add extra municipality name 
ALTER TABLE L6_2
ADD COLUMN MunicipalityName text 
;

UPDATE L6_2 SET MunicipalityName = GemeenteNaam
;

-- add avg time on market
CREATE TABLE L6_3 AS (
SELECT
	MunicipalityName,
	(AVG(TimeOnMarket)) AS GemiddeldeTimeOnMarket
FROM
	L6_1
INNER JOIN L6_2 
    ON L6_1.GemeenteNaam = L6_2.GemeenteNaam
GROUP BY MunicipalityName
);

-- add extra MunicipalityName2
ALTER TABLE L6_3
ADD COLUMN MunicipalityName2 text 
;

UPDATE L6_3 SET MunicipalityName2 = MunicipalityName
;

-- final table
CREATE TABLE L6_final AS (
SELECT
	MunicipalityName2,
	GemiddeldeTimeOnMarket,
	AantalInwoners
FROM
	L6_2
INNER JOIN L6_3
    ON L6_2.GemeenteNaam = L6_3.MunicipalityName
ORDER BY AantalInwoners DESC
);

-- Delete empty row 
DELETE FROM L6_final
WHERE MunicipalityName2 = 'Nuenen'
;

-- Select the table and show 
SELECT *
FROM L6_final 
;

-- drop other tables
DROP TABLE L6_1
;

DROP TABLE L6_2
;

DROP TABLE L6_3
;