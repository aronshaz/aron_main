-- L8: Does the average distance to a train station affect the selling price and/or selling time of a house in every minicipality?

-- Delete tables (so query can be ran again)
DROP TABLE L8_1;
DROP TABLE L8_1AVG;
DROP TABLE L8_2;
DROP TABLE L8_3;

-- Merging required tables
CREATE TABLE L8_1 AS (SELECT KoopPrijs,	GemeenteNaam, timeOnMarket FROM PostcodeTB INNER JOIN Funda_House ON Funda_House.Postcode = PostcodeTB.Postcode 
INNER JOIN Gemeente ON Gemeente.GemeenteCode = PostcodeTB.GemeenteCode ORDER BY KoopPrijs);
DELETE FROM L8_1 WHERE koopprijs = 0;

-- Creating table with average asking price and asking time per municipality
CREATE TABLE L8_1AVG AS (SELECT GemeenteNaam, ROUND(AVG(KoopPrijs)) AS GemiddeldeKoopprijs, AVG(timeOnMarket) AS AVGtimeOnMarket FROM L8_1 GROUP BY GemeenteNaam);
CREATE TABLE L8_2 AS (SELECT AfstandTotTreinstation, GemeenteNaam FROM	Gemeente INNER JOIN Distance ON Distance.GemeenteCode = Gemeente.GemeenteCode ORDER BY AfstandTotTreinstation);

-- add extra municipality name
ALTER TABLE L8_2 ADD COLUMN MunicipalityName text;
UPDATE L8_2 SET MunicipalityName = GemeenteNaam;

-- Combining tables
CREATE TABLE L8_3 AS (SELECT AfstandTotTreinstation, MunicipalityName, GemiddeldeKoopprijs, AVGtimeOnMarket FROM L8_1AVG INNER JOIN L8_2 ON L8_1AVG.GemeenteNaam = L8_2.GemeenteNaam
ORDER BY AfstandTotTreinstation DESC);

-- Select the table 
SELECT * FROM L8_3;
\copy L8_3 to 'L8.csv' csv header;