-- Does the surface area of a house influence the price in every municipality in the Netherlands?

-- Create needed table (koopprijs x sellingtime x gemeentenaam x oppervlakte x perceeloppervlakte )
CREATE TABLE L1_1 AS (
SELECT
	KoopPrijs,
	PerceelOppervlakte,
	Oppervlakte,
	GemeenteNaam,
	DatumOndertekening,
	PublicatieDatum
FROM
	PostcodeTB
INNER JOIN Funda_House 
    ON Funda_House.Postcode = PostcodeTB.Postcode
INNER JOIN Gemeente
    ON Gemeente.GemeenteCode = PostcodeTB.GemeenteCode
ORDER BY KoopPrijs
);

-- remove 0 values ()
DELETE FROM L1_1
WHERE koopprijs = 0
;

-- Add time on market value
ALTER TABLE L1_1
ADD COLUMN TimeOnMarket interval
;

UPDATE L1_1
SET TimeOnMarket = DatumOndertekening - PublicatieDatum
;

-- make table with average asking price per municipality

CREATE TABLE L1_2 AS (
SELECT GemeenteNaam, ROUND(AVG(KoopPrijs)) AS GemiddeldeKoopprijs 
FROM L1_1 
GROUP BY GemeenteNaam
);

-- add extra municipality name 
ALTER TABLE L1_2
ADD COLUMN MunicipalityName text 
;

UPDATE L1_2 SET MunicipalityName = GemeenteNaam
;

-- combine the tables
CREATE TABLE L1_final AS (
SELECT
	PerceelOppervlakte,
	Oppervlakte,
	MunicipalityName,
	KoopPrijs,
	GemiddeldeKoopprijs,
	TimeOnMarket
FROM
	L1_1
INNER JOIN L1_2 
    ON L1_1.GemeenteNaam = L1_2.GemeenteNaam
ORDER BY TimeOnMarket DESC
);

-- Select the table and show 

SELECT *
FROM L1_final 
LIMIT 250
;

-- Drop tables

DROP TABLE L1_1
;

DROP TABLE L1_2
;

-- Select only Amsterdam (or other city)
SELECT *
FROM L1_final 
WHERE MunicipalityName = 'Amsterdam'
LIMIT 250
;

