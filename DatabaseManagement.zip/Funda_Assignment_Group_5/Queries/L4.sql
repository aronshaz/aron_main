-- Literature query 4

-- Distance to huisartsenpraktijk

SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtothuisartsenpraktijk
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtothuisartsenpraktijk
ORDER BY
	gemeentenaam


CREATE TABLE averageafstandtothuisartsenpraktijk AS(
SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtothuisartsenpraktijk
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtothuisartsenpraktijk
ORDER BY
	gemeentenaam);

\copy averageafstandtothuisartsenpraktijk to 'C:\Users\koenm\OneDrive\Bureaublad\afstandtothuisartsenpraktijk.csv' csv header DELIMITER ';';


-- Distance to supermarket

SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtotgrotesupermarkt
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtotgrotesupermarkt
ORDER BY
	gemeentenaam;


CREATE TABLE afstandtotgrotesupermarkt AS(
SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtotgrotesupermarkt
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtotgrotesupermarkt
ORDER BY
	gemeentenaam);

\copy afstandtotgrotesupermarkt to 'C:\Users\koenm\OneDrive\Bureaublad\afstandtotgrotesupermarkt.csv' csv header DELIMITER ';';


-- distance to daycare

SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtotkinderdagverblijf
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtotkinderdagverblijf
ORDER BY
	gemeentenaam;


CREATE TABLE afstandtotkinderdagverblijf AS(
SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtotkinderdagverblijf
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtotkinderdagverblijf
ORDER BY
	gemeentenaam);

\copy afstandtotkinderdagverblijf to 'C:\Users\koenm\OneDrive\Bureaublad\afstandtotkinderdagverblijf.csv' csv header DELIMITER ';';

-- Distance to school

SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtotschool
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtotschool
ORDER BY
	gemeentenaam;


CREATE TABLE afstandtotschool AS(
SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtotschool
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtotschool
ORDER BY
	gemeentenaam);

\copy afstandtotschool to 'C:\Users\koenm\OneDrive\Bureaublad\afstandtotschool.csv' csv header DELIMITER ';';


--Distance to restaurant
SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtotrestaurant
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtotrestaurant
ORDER BY
	gemeentenaam;


CREATE TABLE afstandtotrestaurant AS(
SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtotrestaurant
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtotrestaurant
ORDER BY
	gemeentenaam);

\copy afstandtotrestaurant to 'C:\Users\koenm\OneDrive\Bureaublad\afstandtotrestaurant.csv' csv header DELIMITER ';';


--Distance to trainstation
SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtottreinstation
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtottreinstation
ORDER BY
	gemeentenaam;

CREATE TABLE afstandtottreinstation AS(
SELECT
	AVG(koopprijs)::NUMERIC(10,2) AS averagesellingprice,
	AVG(time_on_market) AS average_time_on_market,
	Gemeentenaam,
	afstandtottreinstation
FROM
	funda_house
	INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
	INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
	INNER JOIN Provincie ON provincie.provinciecode = gemeente.provinciecode
	INNER JOIN distance ON Distance.gemeentecode = gemeente.gemeentecode
GROUP BY
	gemeentenaam,
	afstandtottreinstation
ORDER BY
	gemeentenaam);

\copy afstandtottreinstation to 'C:\Users\koenm\OneDrive\Bureaublad\afstandtottreinstation.csv' csv header DELIMITER ';';