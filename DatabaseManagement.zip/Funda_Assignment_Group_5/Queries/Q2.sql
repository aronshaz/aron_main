-- Q2: Average Asking Price per Population Density Category 

-- Delete tables (so query can be ran again)
DROP TABLE Q2_1;
DROP TABLE Q2_1AVG; 
DROP TABLE Q2_2;
DROP TABLE Q2_3;
DROP TABLE Q2_Final;

-- Merging required tables
CREATE TABLE Q2_1 AS (SELECT KoopPrijs,	GemeenteNaam, DatumOndertekening, PublicatieDatum, ProvincieNaam FROM PostcodeTB INNER JOIN Funda_House ON Funda_House.Postcode = PostcodeTB.Postcode 
INNER JOIN Gemeente ON Gemeente.GemeenteCode = PostcodeTB.GemeenteCode INNER JOIN Provincie ON Provincie.ProvincieCode = Gemeente.ProvincieCode ORDER BY KoopPrijs);
DELETE FROM Q2_1 WHERE koopprijs = 0;

ALTER TABLE Q2_1 ADD COLUMN TimeOnMarket interval;
UPDATE Q2_1 SET TimeOnMarket = DatumOndertekening - PublicatieDatum;

-- Creating table with average asking price per municipality
CREATE TABLE Q2_1AVG AS (SELECT GemeenteNaam, ROUND(AVG(KoopPrijs)) AS GemiddeldeKoopprijs, AVG(TimeOnMarket) AS AVGtimeOnMarket FROM Q2_1 GROUP BY GemeenteNaam);

-- Creating Population Density table per Municipality
CREATE TABLE Q2_2 AS (SELECT Bevolkingsdichtheid, GemeenteNaam FROM	Gemeente INNER JOIN Population ON Population.GemeenteCode = Gemeente.GemeenteCode ORDER BY Bevolkingsdichtheid);
DELETE FROM Q2_2 WHERE Bevolkingsdichtheid = 0;

-- add extra municipality name 
ALTER TABLE Q2_2 ADD COLUMN MunicipalityName text;
UPDATE Q2_2 SET MunicipalityName = GemeenteNaam;

-- Combining tables
CREATE TABLE Q2_3 AS (SELECT Bevolkingsdichtheid, MunicipalityName,	GemiddeldeKoopprijs, AVGtimeOnMarket FROM Q2_1AVG INNER JOIN Q2_2 ON Q2_1AVG.GemeenteNaam = Q2_2.GemeenteNaam
ORDER BY Bevolkingsdichtheid DESC);

-- Adding Population Density category column based on Min and Max values for Population Density for each municipality
ALTER TABLE Q2_3 ADD COLUMN PopulationDensityCategory text;
UPDATE Q2_3 SET PopulationDensityCategory = 'Very High' WHERE Bevolkingsdichtheid > 5200;
UPDATE Q2_3 SET PopulationDensityCategory = 'High' WHERE Bevolkingsdichtheid BETWEEN 3900 AND 5200;
UPDATE Q2_3 SET PopulationDensityCategory = 'Medium' WHERE Bevolkingsdichtheid BETWEEN 2600 AND 3900;
UPDATE Q2_3 SET PopulationDensityCategory = 'Low' WHERE Bevolkingsdichtheid BETWEEN 1300 AND 2600;
UPDATE Q2_3 SET PopulationDensityCategory = 'Very Low' WHERE Bevolkingsdichtheid BETWEEN 0 AND 1300;

-- Calculating average asking price per Population Density Category
CREATE TABLE Q2_Final AS (SELECT PopulationDensityCategory, ROUND(AVG(GemiddeldeKoopprijs)) AS PriceCategoryAVG, AVG(AVGtimeOnMarket) AS TimeCategoryAVG FROM Q2_3 GROUP BY PopulationDensityCategory);

-- Select the table and order 
SELECT * FROM Q2_Final ORDER BY PopulationDensityCategory;
\copy Q2_final to 'Q2.csv' csv header;