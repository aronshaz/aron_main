-- for funda it is interesting to know if the average price is higher in provinces in the 
-- netherlands where the age group is lower, and if the price is lower when the age group is higher. 


-- needed = gemiddelde asking price x age group x the netherlands (province)

-- create needed table (koopprijs x gemeentenaam)


CREATE TABLE q6_1 AS (
SELECT
	KoopPrijs,
	(DatumOndertekening - PublicatieDatum) AS TimeOnMarket,
	GemeenteNaam
FROM
	PostcodeTB
INNER JOIN Funda_House 
    ON Funda_House.Postcode = PostcodeTB.Postcode
INNER JOIN Gemeente
    ON Gemeente.GemeenteCode = PostcodeTB.GemeenteCode
ORDER BY KoopPrijs
);

-- remove 0 values ()

DELETE FROM q6_1
WHERE koopprijs = 0
;

-- make table with average asking price per municipality

CREATE TABLE q6_1gem AS (
SELECT 	GemeenteNaam,
		(AVG(TimeOnMarket)) AS GemiddeldeTimeOnMarket,
		ROUND(AVG(KoopPrijs)) AS GemiddeldeKoopprijs
FROM q6_1 
GROUP BY GemeenteNaam
);

 
-- create needed table (jaar x gemeentenaam)

CREATE TABLE q6_2 AS (
SELECT
	GemeenteNaam,
	Jaar0tot15,
	jaar15tot25,
	jaar25tot45,
	jaar45tot65,
	jaar65ofouder,
	(Jaar0tot15 + jaar15tot25 + jaar25tot45 + jaar45tot65 + jaar65ofouder) as JaarTotaal
FROM
	Gemeente
INNER JOIN Population 
    ON Gemeente.GemeenteCode = Population.GemeenteCode
ORDER BY GemeenteNaam
);

-- add extra municipality name 

ALTER TABLE q6_2
ADD COLUMN MunicipalityName text 
;

UPDATE q6_2 SET MunicipalityName = GemeenteNaam
;
-- combine the tables and add %

CREATE TABLE q6_final AS (
SELECT
	MunicipalityName,
	GemiddeldeKoopprijs,
	GemiddeldeTimeOnMarket,
	jaar0tot15,
	ROUND(jaar0tot15 * 100.0 / JaarTotaal, 1) AS Per0tot15,
	jaar15tot25,
	ROUND(jaar15tot25 * 100.0 / JaarTotaal, 1) AS Per15tot25,
	jaar25tot45,
	ROUND(jaar25tot45 * 100.0 / JaarTotaal, 1) AS Per25tot45,
	jaar45tot65,
	ROUND(jaar45tot65 * 100.0 / JaarTotaal, 1) AS Per45tot65,
	jaar65ofouder,
	ROUND(jaar65ofouder * 100.0 / JaarTotaal, 1) AS Per65ofouder,
	(Jaar0tot15 + jaar15tot25 + jaar25tot45 + jaar45tot65 + jaar65ofouder) as JaarTotaal
FROM
	q6_1gem
INNER JOIN q6_2 
    ON q6_1gem.GemeenteNaam = q6_2.GemeenteNaam
ORDER BY JaarTotaal DESC
);

-- remove empty row
DELETE FROM q6_final
WHERE MunicipalityName = 'Nuenen'
;

-- Select the table and show 

SELECT *
FROM q6_final 
;

-- select only %
SELECT
	MunicipalityName,
	GemiddeldeKoopprijs,
	GemiddeldeTimeOnMarket,
	Per0tot15,
	Per15tot25,
	Per25tot45,
	Per45tot65,
	Per65ofouder,
	JaarTotaal
FROM
	q6_final
;

-- delete old tables 

DROP TABLE q6_1
;

DROP TABLE q6_2
;

DROP TABLE q6_1gem
; 

/*
-- calculate the avarage house price in the netherlands in 2018
SELECT AVG(GemiddeldeKoopprijs)
FROM q6_final
;

-- calculate the avarage time on market in the netherlands in 2018
SELECT AVG(GemiddeldeTimeOnMarket)
FROM q6_final
;
