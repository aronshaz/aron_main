--L7 Does the building age influence the selling price and/or the selling time of a house?

-- Delete tables (so query can be ran again)
DROP TABLE L7_1;
DROP TABLE L7_2;
DROP TABLE L7_3;

-- Merging required tables
CREATE TABLE L7_1 AS (SELECT KoopPrijs,	GemeenteNaam, Bouwjaar, timeOnMarket FROM PostcodeTB INNER JOIN Funda_House ON Funda_House.Postcode = PostcodeTB.Postcode 
INNER JOIN Gemeente ON Gemeente.GemeenteCode = PostcodeTB.GemeenteCode ORDER BY KoopPrijs);
DELETE FROM L7_1 WHERE koopprijs = 0;

-- Creating table with average asking price per municipality
CREATE TABLE L7_2 AS (SELECT GemeenteNaam, ROUND(AVG(KoopPrijs)) AS GemiddeldeKoopprijs FROM L7_1 GROUP BY GemeenteNaam);

-- add extra municipality name
ALTER TABLE L7_2 ADD COLUMN MunicipalityName text;
UPDATE L7_2 SET MunicipalityName = GemeenteNaam;

-- Combining tables
CREATE TABLE L7_3 AS (SELECT Bouwjaar, MunicipalityName, GemiddeldeKoopprijs, KoopPrijs, timeOnMarket FROM L7_1 INNER JOIN L7_2 ON L7_1.GemeenteNaam = L7_2.GemeenteNaam
ORDER BY Bouwjaar DESC);

-- Select the table 
SELECT * FROM L7_3;
\copy L7_3 to 'L7.csv' csv header;