--------- TEXT QUERY (HOUSETYPE): AVERAGE PRICE/TIME PER SOORTWONING ---------------

-- Lexemes for soortWoning

ALTER TABLE funda_house 
ADD lexemesWording tsvector;

UPDATE funda_house 
SET lexemesWording = to_tsvector(soortWoning);



--- COUNT soortWoning

SELECT 'Villa' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('villa')
UNION
SELECT 'Tussenverdieping' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('tussenverdieping')
UNION
SELECT 'Appartement' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('appartement')
UNION
SELECT 'Geschakelde Woning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('geschakelde')
UNION
SELECT 'Dijkwoning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('dijkwoning')
UNION
SELECT 'Landhuis' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('landhuis')
UNION
SELECT 'Maisonnette' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('maisonnette')
UNION
SELECT 'Penthouse' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('penthouse')
UNION
SELECT 'Herenhuis' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('herenhuis')
UNION
SELECT 'Benedenhuis' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('benedenhuis')
UNION
SELECT 'Waterwoning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('waterwoning')
UNION
SELECT 'Hofjeswoning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('hofjeswoning')
UNION
SELECT 'Patiowoning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('patiowoning')
UNION
SELECT 'Benedenhuis' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('benedenhuis')
UNION
SELECT 'Grachtenpand' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('grachtenpand')
UNION
SELECT 'Woonboot' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('woonboot')
UNION
SELECT 'Benedenwoning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('benedenwoning')
UNION
SELECT 'Bovenwoning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('bovenwoning')
UNION
SELECT 'Portiekflat' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('portiekflat')
UNION
SELECT 'Galerijflat' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('galerijflat')
UNION
SELECT 'Split-level Woning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('split-level')
UNION
SELECT 'Eindwoning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('eindwoning')
UNION
SELECT 'Bovenhuis' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('bovenhuis')
UNION
SELECT 'Portiekwoning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('portiekwoning')
UNION
SELECT 'Hoekwoning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('hoekwoning')
UNION
SELECT 'Souterrain' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('souterrain')
UNION
SELECT 'Woonboerderij' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('woonboerderij')
UNION
SELECT 'Eengezinswoning' AS Term, count(*) AS term_occurence, ROUND(avg(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_time FROM funda_house WHERE lexemesWording @@ to_tsquery('Eengezinswoning');



------- Average prices and average time on market per gemeente (TOP 15 based on occurence, price and time)

-- 1. Eengezinswoning
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Eengezinswoning_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Eengezinswoning')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 2. Appartement
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Appartement_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Appartement')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 3. Hoekwoning
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Hoekwoning_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Hoekwoning')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 4. Portiekflat
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Portiekflat_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Portiekflat')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 5. Bovenwoning
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Bovenwoning_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Bovenwoning')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 6. Galerijflat
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Galerijflat_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Galerijflat')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 7. Portiekwoning
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Portiekwoning_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Portiekwoning')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 8. Benedenhuis
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Benedenhuis_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Benedenhuis')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 9. Benedenwoning
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Benedenwoning_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Benedenwoning')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 10. Villa
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Villa_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Villa')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 11. Maisonnette
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Maisonnette_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Maisonnette')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 12. Penthouse
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Penthouse_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Penthouse')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 13. Landhuis
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Landhuis_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Landhuis')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 14. Bovenhuis
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Bovenhuis_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Bovenhuis')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;

-- 15. Grachtenpand
SELECT Gemeente.GemeenteNaam as Gemeente,
ROUND(avg(koopPrijs), 2) as Grachtenpand_avg_price,
avg(timeOnMarket)
FROM funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
WHERE lexemesWording @@ to_tsquery('Grachtenpand')
GROUP BY
gemeentenaam
ORDER BY
gemeentenaam;
