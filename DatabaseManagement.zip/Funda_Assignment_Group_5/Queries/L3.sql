-- Does a longer selling time means a higher selling price?

-- Add in: different housetypes 

-- Create needed table (koopprijs x sellingtime x soortwoning)

CREATE TABLE L3_1 AS (
SELECT
	KoopPrijs,
	SoortWoning,
	DatumOndertekening,
	PublicatieDatum
FROM
	Funda_House
ORDER BY KoopPrijs
);

-- remove 0 values ()
DELETE FROM L3_1
WHERE koopprijs = 0
;

-- Add time on market value
ALTER TABLE L3_1
ADD COLUMN TimeOnMarket interval
;

UPDATE L3_1
SET TimeOnMarket = DatumOndertekening - PublicatieDatum
;

-- final table 
CREATE TABLE L3_final AS (
SELECT
	KoopPrijs,
	SoortWoning,
	TimeOnMarket
FROM
	L3_1
ORDER BY TimeOnMarket DESC
);

-- Select the table and show 

SELECT *
FROM L3_final 
LIMIT 250
;

-- drop other tables
DROP TABLE L3_1
;
