-- Is the average asking price (and selling time) higher at the municipality with a higher average income per inhabitant? 

-- create needed table (koopprijs x gemeentenaam)

CREATE TABLE q3_1 AS (
SELECT
	KoopPrijs,
	(DatumOndertekening - PublicatieDatum) AS TimeOnMarket,
	GemeenteNaam
FROM
	PostcodeTB
INNER JOIN Funda_House 
    ON Funda_House.Postcode = PostcodeTB.Postcode
INNER JOIN Gemeente
    ON Gemeente.GemeenteCode = PostcodeTB.GemeenteCode
ORDER BY KoopPrijs
);

-- remove 0 values ()
DELETE FROM q3_1
WHERE koopprijs = 0
;

-- make table with average asking price per municipality
CREATE TABLE q3_1gem AS (
SELECT 	GemeenteNaam,
		(AVG(TimeOnMarket)) AS GemiddeldeTimeOnMarket,
		ROUND(AVG(KoopPrijs)) AS GemiddeldeKoopprijs 
FROM q3_1 
GROUP BY GemeenteNaam
);

-- join all 

-- create needed table (gemeentenaam x average income per inhabitant)

CREATE TABLE q3_2 AS (
SELECT
	GemiddeldInkomenPerInwoner,
	GemeenteNaam
FROM
	Population
INNER JOIN Gemeente 
    ON Population.GemeenteCode = Gemeente.GemeenteCode
ORDER BY GemiddeldInkomenPerInwoner
);


-- remove 0 values 

DELETE FROM q3_2
WHERE GemiddeldInkomenPerInwoner = 0 -- Or "NULL"
;

-- add extra municipality name 

ALTER TABLE q3_2
ADD COLUMN MunicipalityName text 
;

UPDATE q3_2 SET MunicipalityName = GemeenteNaam
;

-- combine the tables 

CREATE TABLE q3_final AS (
SELECT
	GemiddeldInkomenPerInwoner,
	MunicipalityName,
	GemiddeldeKoopprijs,
	GemiddeldeTimeOnMarket
FROM
	q3_1gem
INNER JOIN q3_2 
    ON q3_1gem.GemeenteNaam = q3_2.GemeenteNaam
ORDER BY GemiddeldInkomenPerInwoner DESC
);

-- remove empty row
DELETE FROM q3_final
WHERE MunicipalityName = 'Nuenen'
;

-- Select the table and show 

SELECT *
FROM q3_final 
;

-- delete old tables 

DROP TABLE q3_1
;

DROP TABLE q3_2
;

DROP TABLE q3_1gem
; 

