------------- SQL QUERY 5 + TIME ON MARKET ---------------------

-- prestep: create function to use the abs() function for data type interval
CREATE FUNCTION abs(interval) RETURNS interval AS
$$ select case when ($1<interval '0') then -$1 else $1 end; $$ LANGUAGE sql immutable;

-- query
SELECT
date_part('year', publicatiedatum) AS publicationyear,
date_part('month', publicatiedatum) AS publicationmonth,
gemeentenaam,
percentile_cont(0.5) WITHIN GROUP(ORDER BY koopprijs) AS medianlistingprice,
ABS((percentile_cont(0.5) WITHIN GROUP(ORDER BY koopprijs))-lag(percentile_cont(0.5) WITHIN GROUP(ORDER BY koopprijs)) over (order by gemeentenaam)) as abs_median_price_difference,
percentile_cont(0.5) WITHIN GROUP(order by (DatumOndertekening - publicatiedatum)) as mediansellingtime,
ABS(percentile_cont(0.5) WITHIN GROUP(ORDER BY (DatumOndertekening - publicatiedatum))-lag(percentile_cont(0.5) WITHIN GROUP(ORDER BY (DatumOndertekening - publicatiedatum))) over (order by gemeentenaam)) as abs_median_time_difference
FROM
funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
GROUP BY
date_part('year', publicatiedatum),
date_part('month', publicatiedatum),
gemeentenaam
ORDER BY
gemeentenaam,
date_part('year', publicatiedatum),
date_part('month', publicatiedatum);