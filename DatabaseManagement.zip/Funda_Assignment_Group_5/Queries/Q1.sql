------------- SQL QUERY 1 + TIME ON MARKET---------------------

SELECT
gemeentenaam,
date_part('year', publicatiedatum) AS publicationyear,
date_part('month', publicatiedatum) AS publicationmonth,
ROUND(AVG(koopprijs), 2) AS averagelistingprice,
AVG(DatumOndertekening - publicatiedatum) AS averagesellingtime
FROM
funda_house
INNER JOIN PostcodeTB ON PostcodeTB.postcode = funda_house.postcode
INNER JOIN Gemeente ON Gemeente.gemeentecode = PostcodeTB.gemeentecode
GROUP BY
date_part('year', publicatiedatum),
date_part('month', publicatiedatum),
gemeentenaam
ORDER BY
gemeentenaam;