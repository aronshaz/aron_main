------ TEXT QUERY (TERMS): TERMS USED IN SUMMARY ------


-- Lexemes for volledigeOmschrijving

ALTER TABLE funda_house 
ADD lexemesWording3 tsvector;

UPDATE funda_house
SET lexemesWording3 = to_tsvector(VolledigeOmschijving);


-- Checking terms for number of occurence and average asking price

SELECT '    "mooie"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('mooie')
UNION
SELECT 'not "mooie"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('mooie');

SELECT '    "gezellig"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('gezellig')
UNION
SELECT 'not "gezellig"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('gezellig');

SELECT '    "Restaurant"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('Restaurant')
UNION
SELECT 'not "Restaurant"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('Restaurant');

SELECT '    "gemotiveerd"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('gemotiveerd')
UNION
SELECT 'not "gemotiveerd"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('gemotiveerd');

SELECT '    "landschap"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('landschap')
UNION
SELECT 'not "landschap"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('landschap');

SELECT '    "park"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('park')
UNION
SELECT 'not "park"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('park');

SELECT '    "bomen"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('bomen')
UNION
SELECT 'not "bomen"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('bomen');

SELECT '    "groen"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('groen')
UNION
SELECT 'not "groen"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('groen');

SELECT '    "centrum"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('centrum')
UNION
SELECT 'not "centrum"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('centrum');

SELECT '    "kindvriendelijk"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('kindvriendelijk')
UNION
SELECT 'not "kindvriendelijk"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('kindvriendelijk');

SELECT '    "speeltuin"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('speeltuin')
UNION
SELECT 'not "speeltuin"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('speeltuin');

SELECT '    "supermarkt"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('supermarkt')
UNION
SELECT 'not "supermarkt"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('supermarkt');

SELECT '    "gerenoveerd"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('gerenoveerd')
UNION
SELECT 'not "gerenoveerd"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('gerenoveerd');

SELECT '    "modern"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('modern')
UNION
SELECT 'not "modern"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('modern');

SELECT '    "ruimte"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('ruimte')
UNION
SELECT 'not "ruimte"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('ruimte');

SELECT '    "luxe"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('luxe')
UNION
SELECT 'not "luxe"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('luxe');

SELECT '    "school"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('school')
UNION
SELECT 'not "school"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('school');

SELECT '    "parkeerplaats"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('parkeerplaats')
UNION
SELECT 'not "parkeerplaats"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('parkeerplaats');

SELECT '    "treinstation"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('treinstation')
UNION
SELECT 'not "treinstation"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('treinstation');

SELECT '    "huisarts"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE lexemesWording3 @@ to_tsquery('huisarts')
UNION
SELECT not '"huisarts"' AS Term, COUNT (funda_house.VolledigeOmschijving) AS occurrence, ROUND(AVG(koopPrijs), 2) AS average_price, avg(timeOnMarket) AS average_timeOnMarket
FROM funda_house 
WHERE NOT lexemesWording3 @@ to_tsquery('huisarts');