##### Environment #####
if(!require('car') ){ install.packages('car') }
library(car)

if(!require('regclass') ){ install.packages('regclass') }
library(regclass)

if(!require('ggplot2') )install.packages('ggplot2') 
library(ggplot2)

if(!require('corrplot')) install.packages('corrplot')
library(corrplot)

if(!require('corrplot')) install.packages('remotes')
library(dplyr)

if(!require('GGally') ){ install.packages('GGally') }
library("GGally")

if(!require('tidyverse') ){ install.packages('tidyverse') }
library(tidyverse)

setwd("C:\\Users\\aronk\\Desktop\\DM_DT")

##### Distance To TrainStation #####
distanceTrainStation <- read.csv2("L8.csv", header = TRUE, sep = ",")
distanceTrainStation$afstandtottreinstation <- as.numeric(distanceTrainStation$afstandtottreinstation)

distanceTrainStation %>% select(afstandtottreinstation, avgtimeonmarket) %>% ggpairs()
distanceTrainStation %>% cor %>% corrplot.mixed()
lm(avgtimeonmarket ~ afstandtottreinstation, data=distanceTrainStation) %>% summary

ggplot(distanceTrainStation,aes(x= afstandtottreinstation, y= avgtimeonmarket)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, size = 1)


##### Population Density #####
pop_density <- read.csv2("Q2.csv", header = TRUE, sep = ',')
str(pop_density)

barplot(height=pop_density$timecategoryavg, main="Population Density vs Selling Time", names.arg = pop_density$populationdensitycategory, las = 2, cex.lab=0.5, cex.names=0.5)
lm(timecategoryavg ~ populationdensitycategory, data=pop_density) %>% summary
plot(lm(timecategoryavg ~ populationdensitycategory, data=pop_density))

barplot(height=pop_density$pricecategoryavg, main="Population Density vs Listing Price", names.arg = pop_density$populationdensitycategory, las = 2, cex.lab=0.5, cex.names=0.5)
lm(pricecategoryavg ~ populationdensitycategory, data=pop_density) %>% summary
plot(lm(pricecategoryavg ~ populationdensitycategory, data=pop_density))

aov1 = aov(populationdensitycategory ~ timecategoryavg, data=pop_density)
summary(aov1)

##### Build Year #####
build_year <- read.csv2("L7_2.csv", header = TRUE, sep = ",")

build_year %>% cor %>% corrplot.mixed()

build_year %>% select(afstandtottreinstation, gemiddeldekoopprijs, avgtimeonmarket) %>% ggpairs()
str(build_year)

build_year %>% select(�..bouwjaar, koopprijs, timeonmarket) %>% cor %>% corrplot.mixed()

ggplot(build_year,aes(x= �..bouwjaar, y= koopprijs)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, size = 1)

lm(timeonmarket ~ �..bouwjaar, data=build_year) %>% summary
