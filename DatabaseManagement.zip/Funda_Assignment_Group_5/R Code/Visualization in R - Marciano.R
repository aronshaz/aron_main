# Environment load ####
if(!require('rstudioapi') ){ install.packages('rstudioapi') }
library(rstudioapi)
if(!require('rpistudio') ){ install.packages('rpistudio') }
library(rpistudio)
if(!require('evaluate') ){ install.packages('evaluate') }
library(evaluate)
if(!require('tidyverse') ){ install.packages('tidyverse') }
library(tidyverse)
if(!require('htmlwidgets') ){ install.packages('htmlwidgets') }
library(htmlwidgets)
if(!require('DataExplorer') ){ install.packages('DataExplorer') }
library(DataExplorer)
if(!require('GGally') ){ install.packages('GGally') }
library(GGally)
if(!require('ggplot2') ){ install.packages('ggplot2') }
library(ggplot2)
if(!require('corrplot') ){ install.packages('corrplot') }
library(corrplot)
if(!require('ggcorrplot') ){ install.packages('ggcorrplot') }
library(ggcorrplot)
if(!require('ggstance') ){ install.packages('ggstance') }
library(ggstance)
if(!require('car') ){ install.packages('car') }
library(car)


#get WD
getwd()


# Q3 Is the average asking price (and selling time) higher at the municipality ####
# with a higher average income per inhabitant? 

#Q3 = read.csv("Q3.csv", header = TRUE) if csv , 
Q3 = read.csv("Q3.csv", header = TRUE, sep=";")

# is the asking price higher in municipality with higher average income?

Q3 %>% select(gemiddeldinkomenperinwoner, gemiddeldekoopprijs ) %>% cor %>% corrplot.mixed()

Q3 %>% select(gemiddeldinkomenperinwoner, gemiddeldekoopprijs) %>% ggpairs()

lm(gemiddeldinkomenperinwoner ~ gemiddeldekoopprijs, data=Q3) %>% plot_res

ggplot(Q3,aes(x= gemiddeldinkomenperinwoner, y=gemiddeldekoopprijs)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, size = 1)

lm(gemiddeldinkomenperinwoner ~ gemiddeldekoopprijs, data=Q3) %>% summary
# p-value: < 2.2e-16
# Adjusted R-squared:  0.7475
# Corr: 0.86

# barchart with added parameters

options(scipen=999) # remove scientific notation

# barplot(Q3$gemiddeldekoopprijs, main="Gemiddele Inkomen vs Gemiddelde Inkoopprijs", xlab="Gemiddelde Inkomen x 1.000", ylab="Gemiddelde Koopprijs", names= Q3$municipalityname, las = 1)

# is the average selling time higher at the municipality with a higher average income? 

Q3 %>% select(gemiddeldinkomenperinwoner, gemiddeldetimeonmarket ) %>% cor %>% corrplot.mixed()

Q3 %>% select(gemiddeldinkomenperinwoner, gemiddeldetimeonmarket) %>% ggpairs()

lm(gemiddeldinkomenperinwoner ~ gemiddeldetimeonmarket, data=Q3) %>% plot_res

ggplot(Q3,aes(x= gemiddeldinkomenperinwoner, y=gemiddeldetimeonmarket)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, size = 1)

lm(gemiddeldinkomenperinwoner ~ gemiddeldetimeonmarket, data=Q3) %>% summary
# p-value: 2.941e-09
# Adjusted R-squared:  0.08756
# Corr: -0.3
# some big outliers 

# Q3$gemiddeldetimeonmarket <- as.integer(Q3$gemiddeldetimeonmarket)  

# Q5 the absolute difference between the median house price for that month in that ####
# gemeente and the median house price for the next month in that gemeente

Q5_ams = read.csv("Q5_amsterdam.csv", header = TRUE, sep=";")

# display only for Amsterdam

# price x month

barplot(height=Q5_ams$medianlistingprice, main="Month vs Median Listing Price in Amsterdam", names.arg = Q5_ams$publicationmonth, las = 1, cex.lab=0.5, cex.names=0.8)

# time x month

barplot(height=Q5_ams$mediansellingtime, main="Month vs Median Selling Time in Amsterdam", names.arg = Q5_ams$publicationmonth, las = 1, cex.lab=0.5, cex.names=0.8)

# display only for Appingendam

Q5_app = read.csv("Q5_appingendam.csv", header = TRUE, sep=";")

barplot(height=Q5_app$medianlistingprice, main="Month vs Median Listing Price in Appingendam", names.arg = Q5_app$publicationmonth, las = 1, cex.lab=0.5, cex.names=0.8)

# time x month

barplot(height=Q5_app$mediansellingtime, main="Month vs Median Selling Time in Appingendam", names.arg = Q5_app$publicationmonth, las = 1, cex.lab=0.5, cex.names=0.8)



# Q6 if the average price is higher in municipalities in the netherlands where the age group is lower ####
# and if the price is lower when the age group is higher.

#Q6 = read.csv("Q6.csv", header = TRUE) if no , but ;
Q6 = read.csv("Q6.csv", header = TRUE, sep=";")

# does the price has a relation to an age group?

Q6 %>% select(gemiddeldekoopprijs, jaar0tot15, jaar15tot25,jaar25tot45, jaar45tot65,jaar65ofouder) %>% cor %>% corrplot.mixed()

Q6 %>% select(gemiddeldekoopprijs, jaar0tot15, jaar15tot25,jaar25tot45, jaar45tot65,jaar65ofouder) %>% ggpairs()

# no correlation

# does the selling time has a relation to an age group?

Q6 %>% select(gemiddeldetimeonmarket, jaar0tot15, jaar15tot25,jaar25tot45, jaar45tot65,jaar65ofouder) %>% cor %>% corrplot.mixed()

Q6 %>% select(gemiddeldetimeonmarket, jaar0tot15, jaar15tot25,jaar25tot45, jaar45tot65,jaar65ofouder) %>% ggpairs()

# no different correlation


# L1 Does the surface area of a house influence the price in every municipality in the Netherlands? ####

L1 = read.csv("L1.csv", header = TRUE, sep=";")

# does oppervlakte and perceeloppervlakte has a relation to koopprijs

L1 %>% select(oppervlakte, perceeloppervlakte, koopprijs) %>% cor %>% corrplot.mixed()

ggplot(L1,aes(x= oppervlakte, y= koopprijs)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, size = 1)

lm(koopprijs ~ oppervlakte, data=L1) %>% summary
# p-value: < 2.2e-16
# Adjusted R-squared:  0.4291
# Corr: 0.66
# had to remove a lot of data hat was not correct (- time or 0 days) also some outliers 
# find out if it is different per gemeente

# does oppervlakte and perceeloppervlakte has a relation to selling time

L1 %>% select(oppervlakte, perceeloppervlakte, timeonmarket) %>% cor %>% corrplot.mixed()

ggplot(L1,aes(x= oppervlakte, y= timeonmarket)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, size = 1)

lm(timeonmarket ~ oppervlakte, data=L1) %>% summary
# p-value: < 2.2e-16
# Adjusted R-squared:  0.05455
# Corr: 0.23
# had to remove a lot of data hat was not correct (- time or 0 days) also some outliers 

# L3 Does a longer selling time means a higher selling price? ####

L3 = read.csv("L3.csv", header = TRUE, sep=";")

L3 %>% select(�..koopprijs, timeonmarket ) %>% cor %>% corrplot.mixed()

L3 %>% select(�..koopprijs, timeonmarket ) %>% ggpairs()

lm(timeonmarket ~ �..koopprijs, data=L3) %>% plot_res

ggplot(L3,aes(x= timeonmarket, y= �..koopprijs)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, size = 1)

lm(timeonmarket ~ �..koopprijs, data=L3) %>% summary
# p-value: < 2.2e-16
# Adjusted R-squared:  0.02486
# Corr: 0.16
#had to remove a lot of data hat was not correct (- time or 0 days)

# L6 Does it take longer to sell houses in bigger cities? ####

L6 = read.csv("L6.csv", header = TRUE)

L6 %>% select(gemiddeldektimeonmarket, aantalinwoners ) %>% cor %>% corrplot.mixed()

L6 %>% select(gemiddeldektimeonmarket, aantalinwoners) %>% ggpairs()

lm(gemiddeldektimeonmarket ~ aantalinwoners, data=L6) %>% plot_res

ggplot(L6,aes(x= aantalinwoners, y= gemiddeldektimeonmarket)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, size = 1)

lm(gemiddeldektimeonmarket ~ aantalinwoners, data=L6) %>% summary
# p-value: 1.084e-10
# Adjusted R-squared:  0.1024 
# Corr: -0.324
# few very big outliers

# T1 Does the type of house have a different price and selling time? ####

# price x type
T1 = read.csv("T1.csv", header = TRUE, sep=";")

barplot(height=T1$average_price, main="Type Huis vs Gemiddelde koopprijs", names.arg = T1$�..term, las = 2, cex.lab=0.5, cex.names=0.5)

# time x type
T1_1 = read.csv("T1_1.csv", header = TRUE, sep=";")

barplot(height=T1_1$average_time, main="Type Huis vs Gemiddelde verkooptijd", names.arg = T1_1$term, las = 2, cex.lab=0.5, cex.names=0.5)

# correlation in time and price per type of house 
T1_2 = read.csv("T1_2.csv", header = TRUE, sep=";")

T1_2 %>% select(average_price, average_time) %>% cor %>% corrplot.mixed()

ggplot(T1_2,aes(x= average_price, y= average_time)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, size = 1)

lm(average_time ~ average_price, data=T1_2) %>% summary
# p-value: 0.0003352
# Adjusted R-squared:  0.3844
# Corr: 0.64

cor.test(T1_2$average_price, T1_2$average_time, method = "pearson")


