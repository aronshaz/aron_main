library(tidyverse)
library(GGally)
library(readxl)
#Literature query 2####
averageprovincie <- read_excel("averageprovince.xlsx")
averagelanddeel <- read_excel("averagelanddeel.xlsx")
averagegemeente <- read_excel("averagegemeente.xlsx")
options(scipen=999) # remove scientific notation


#barplot gemeente / Average Listing price####

barplot(height = averagegemeente$averagesellingprice,
        names.arg = averagegemeente$gemeentenaam,
        main = "Average house price per gemeente",
        col = "#69b3a2",
        las = 2,
        cex.names = 0.5)

#barplot gemeente / time on market####

barplot(height = averagegemeente$average_time_on_market,
        names.arg = averagegemeente$gemeentenaam,
        main = "Average time on market price per gemeente",
        col = "#69b3a2",
        las = 2,
        cex.names = 0.5)
#Barplot province / average Listing price####

barplot(height = averageprovincie$averagesellingprice,
        names.arg = averageprovincie$provincienaam,
        main = "Average house price per province",
        col = "#69b3a2",
        las = 2,
        cex.names = 0.7)

#barplot province / time on market####

barplot(height = averageprovincie$average_time_on_market,
        names.arg = averageprovincie$provincienaam,
        ylab = "days",
        main = "Average time on market per province",
        col = "#69b3a2",
        las = 2,
        cex.names = 0.7)
#barplot landdeel / average house price####

barplot(height = averagelanddeel$averagesellingprice,
        names.arg = averagelanddeel$landdeelnaam,
        main = "Average house price per Landdeel",
        col = "#69b3a2",
        las = 2,
        cex.names = 0.6)

#Barplot landdeel / time on market####

barplot(height = averagelanddeel$average_time_on_market,
        names.arg = averagelanddeel$landdeelnaam,
        ylab = "days",
        main = "Average time on market per province",
        col = "#69b3a2",
        las = 2,
        cex.names = 0.5)

#Literature query 4####
Distancetosupermarket <- read_excel("afstandtotgrotesupermarkt.xlsx")
Distancetodoctor <- read_excel("afstandtothuisartsenpraktijk.xlsx")
distancetodaycare <- read_excel("Afstandtotkinderdagverblijf.xlsx")
Distancetorestaurant <- read_excel("afstandtotrestaurant.xlsx")
Distancetoschool <- read_excel("afstandtotschool.xlsx")
Distancetotrainstation <- read_excel("afstandtottreinstation.xlsx")


#Check for correlations between the  distances to supermarket and price####
cor.test(Distancetosupermarket$afstandtotgrotesupermarkt, 
         Distancetosupermarket$averagesellingprice, 
         method = c("pearson"))

lm(Distancetosupermarket$afstandtotgrotesupermarkt ~
   Distancetosupermarket$averagesellingprice, 
   data = Distancetosupermarket) %>% summary

#Check for correlations between the  distances to supermarket and time on market####
cor.test(Distancetosupermarket$afstandtotgrotesupermarkt, 
         Distancetosupermarket$average_time_on_market,
         method = c("pearson"))

lm(Distancetosupermarket$afstandtotgrotesupermarkt ~
     Distancetosupermarket$average_time_on_market, 
   data = Distancetosupermarket) %>% summary

Distancetosupermarket %>% select(afstandtotgrotesupermarkt, average_time_on_market) %>% ggpairs()

#Check for correlations between the  distances to huisartsenpraktijk and the price of house####
cor.test(Distancetodoctor$afstandtothuisartsenpraktijk,
         Distancetodoctor$averagesellingprice,
         method = c("pearson"))

lm(Distancetodoctor$afstandtothuisartsenpraktijk ~
     Distancetodoctor$averagesellingprice, 
   data = Distancetodoctor) %>% summary

#Check for correlations between the  distances to huisartsenpraktijk and time on market####

cor.test(Distancetodoctor$afstandtothuisartsenpraktijk, 
         Distancetodoctor$average_time_on_market,
         method = c("pearson"))

lm(Distancetodoctor$afstandtothuisartsenpraktijk ~
     Distancetodoctor$average_time_on_market, 
   data = Distancetodoctor) %>% summary

Distancetodoctor %>% select(afstandtothuisartsenpraktijk, average_time_on_market) %>% ggpairs()

#Check for correlations between the  distances to daycare and the average price of house####
cor.test(distancetodaycare$afstandtotkinderdagverblijf, 
         distancetodaycare$averagesellingprice,
         method = c("pearson"))

lm(distancetodaycare$afstandtotkinderdagverblijf ~
     distancetodaycare$averagesellingprice, 
   data = distancetodaycare) %>% summary

#Check for correlations between the distances to Daycare and time on market####

cor.test(distancetodaycare$afstandtotkinderdagverblijf, 
         distancetodaycare$average_time_on_market,
         method = c("pearson"))

lm(distancetodaycare$afstandtotkinderdagverblijf ~
     distancetodaycare$average_time_on_market, 
   data = distancetodaycare) %>% summary

distancetodaycare %>% select(afstandtotkinderdagverblijf, average_time_on_market) %>% ggpairs()


#Check for correlations between the Distance to a reastaurant and avarage house price####
cor.test(Distancetorestaurant$afstandtotrestaurant,
         Distancetorestaurant$averagesellingprice,
         method = c("pearson"))

lm(Distancetorestaurant$afstandtotrestaurant ~
     Distancetorestaurant$averagesellingprice, 
   data = Distancetorestaurant) %>% summary

#Check for correlations between the Distance to a reastaurant and time on market####

cor.test(Distancetorestaurant$afstandtotrestaurant,
         Distancetorestaurant$average_time_on_market,
         method = c("pearson"))

lm(Distancetorestaurant$afstandtotrestaurant ~
     Distancetorestaurant$average_time_on_market, 
   data = Distancetorestaurant) %>% summary

Distancetorestaurant %>% select(afstandtotrestaurant, average_time_on_market) %>% ggpairs()

#Check for correlations between the distance to a school and the average house price####
cor.test(Distancetoschool$afstandtotschool,
         Distancetoschool$averagesellingprice,
         method = c("pearson"))

lm(Distancetoschool$afstandtotschool ~
     Distancetoschool$averagesellingprice, 
   data = Distancetoschool) %>% summary

#Check for correlations between the distance to a school and the average time on market####

cor.test(Distancetoschool$afstandtotschool,
         Distancetoschool$average_time_on_market,
         method = c("pearson"))


lm(Distancetoschool$afstandtotschool ~
     Distancetoschool$average_time_on_market, 
   data = Distancetoschool) %>% summary

Distancetoschool %>% select(afstandtotschool, average_time_on_market) %>% ggpairs()


#Check for correlations between the distance to a trainstation and the average house price####
cor.test(Distancetotrainstation$afstandtottreinstation,
         Distancetotrainstation$averagesellingprice,
         method = c("pearson"))

lm(Distancetotrainstation$afstandtottreinstation ~
     Distancetotrainstation$averagesellingprice, 
   data = Distancetotrainstation) %>% summary

#Check for correlations between the distance to a trainstation and the average time on market#####


cor.test(Distancetotrainstation$afstandtottreinstation,
         Distancetotrainstation$average_time_on_market,
         method = c("pearson"))

lm(Distancetotrainstation$afstandtottreinstation ~
     Distancetotrainstation$average_time_on_market, 
   data = Distancetotrainstation) %>% summary

Distancetotrainstation %>% select(afstandtottreinstation, average_time_on_market) %>% ggpairs()
  
